import { NextResponse } from "next/server";
import path from "node:path";
import { mkdir, writeFile } from "node:fs/promises";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session } from "@/server/session";

const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25MB MVP guardrail
export const runtime = "nodejs";

function getRequestOrigin(req: Request) {
  const url = new URL(req.url);
  const forwardedProto = req.headers.get("x-forwarded-proto");
  const forwardedHost = req.headers.get("x-forwarded-host");
  const host = forwardedHost ?? req.headers.get("host");
  const protocol = forwardedProto ?? url.protocol.replace(":", "");
  return host ? `${protocol}://${host}` : url.origin;
}

function extensionFrom(fileName: string) {
  const ext = path.extname(fileName).toLowerCase();
  if (!ext) return ".bin";
  return ext;
}

export async function POST(req: Request) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return withCookie(NextResponse.json({ error: "file is required" }, { status: 400 }));
    }

    if (file.size <= 0) {
      return withCookie(NextResponse.json({ error: "Empty file" }, { status: 400 }));
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      return withCookie(
        NextResponse.json(
          { error: `파일이 너무 큽니다. 현재 업로드 제한은 ${Math.floor(MAX_UPLOAD_BYTES / (1024 * 1024))}MB 입니다.` },
          { status: 400 }
        )
      );
    }

    const bytes = Buffer.from(await file.arrayBuffer());
    const ext = extensionFrom(file.name);
    const safeName = `${Date.now()}-${crypto.randomUUID()}${ext}`;
    const uploadDir = path.join(process.cwd(), "public", "uploads");
    await mkdir(uploadDir, { recursive: true });
    const filePath = path.join(uploadDir, safeName);
    await writeFile(filePath, bytes);

    const origin = getRequestOrigin(req);
    const url = `${origin}/uploads/${safeName}`;
    return withCookie(NextResponse.json({ url, bytes: file.size, mimeType: file.type || null }));
  } catch (err) {
    const details = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error: details }, { status: 500 }));
  }
}
