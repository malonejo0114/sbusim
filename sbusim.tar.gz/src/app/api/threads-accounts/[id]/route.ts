import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { encryptString } from "@/server/crypto";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session, upsertUserById } from "@/server/session";

const UpdateAccountSchema = z.object({
  label: z.string().trim().max(80).optional(),
  proxyUrl: z.string().trim().max(500).optional(),
});

function validateProxyUrl(proxyUrl: string) {
  const u = new URL(proxyUrl);
  if (u.protocol !== "http:" && u.protocol !== "https:") {
    throw new Error("proxyUrl must start with http:// or https://");
  }
  return u.toString();
}

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  try {
    await upsertUserById(userId);
    const { id } = await ctx.params;
    const account = await prisma.threadsAccount.findFirst({
      where: { id, userId },
      select: {
        id: true,
        label: true,
        threadsUserId: true,
        threadsUsername: true,
        proxyUrlEncrypted: true,
        tokenExpiresAt: true,
        createdAt: true,
        updatedAt: true,
      },
    });
    if (!account) return withCookie(NextResponse.json({ error: "Not found" }, { status: 404 }));

    return withCookie(
      NextResponse.json({
        account: {
          id: account.id,
          label: account.label,
          threadsUserId: account.threadsUserId,
          threadsUsername: account.threadsUsername,
          hasProxy: Boolean(account.proxyUrlEncrypted),
          tokenExpiresAt: account.tokenExpiresAt.toISOString(),
          createdAt: account.createdAt.toISOString(),
          updatedAt: account.updatedAt.toISOString(),
        },
      })
    );
  } catch (err) {
    const details = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error: details }, { status: 500 }));
  }
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  const json = await req.json().catch(() => null);
  const parsed = UpdateAccountSchema.safeParse(json);
  if (!parsed.success) {
    return withCookie(NextResponse.json({ error: parsed.error.flatten() }, { status: 400 }));
  }

  const { id } = await ctx.params;
  const account = await prisma.threadsAccount.findFirst({
    where: { id, userId },
  });
  if (!account) return withCookie(NextResponse.json({ error: "Not found" }, { status: 404 }));

  try {
    await upsertUserById(userId);
    const proxyProvided =
      typeof json === "object" &&
      json !== null &&
      Object.prototype.hasOwnProperty.call(json, "proxyUrl");
    const proxyInput = proxyProvided ? (parsed.data.proxyUrl ?? "").trim() : undefined;

    const data: {
      label?: string | null;
      proxyUrlEncrypted?: string | null;
    } = {};

    if (parsed.data.label !== undefined) {
      data.label = parsed.data.label.trim() || null;
    }
    if (proxyInput !== undefined) {
      data.proxyUrlEncrypted = proxyInput ? encryptString(validateProxyUrl(proxyInput)) : null;
    }

    if (Object.keys(data).length === 0) {
      return withCookie(
        NextResponse.json({
          account: {
            id: account.id,
            label: account.label,
            threadsUserId: account.threadsUserId,
            threadsUsername: account.threadsUsername,
            hasProxy: Boolean(account.proxyUrlEncrypted),
            tokenExpiresAt: account.tokenExpiresAt.toISOString(),
          },
        })
      );
    }

    const updated = await prisma.threadsAccount.update({
      where: { id },
      data,
    });

    return withCookie(
      NextResponse.json({
        account: {
          id: updated.id,
          label: updated.label,
          threadsUserId: updated.threadsUserId,
          threadsUsername: updated.threadsUsername,
          hasProxy: Boolean(updated.proxyUrlEncrypted),
          tokenExpiresAt: updated.tokenExpiresAt.toISOString(),
        },
      })
    );
  } catch (err) {
    const details = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error: details }, { status: 400 }));
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  try {
    await upsertUserById(userId);
    const { id } = await ctx.params;
    const account = await prisma.threadsAccount.findFirst({
      where: { id, userId },
      select: {
        id: true,
        label: true,
        threadsUsername: true,
        threadsUserId: true,
      },
    });
    if (!account) return withCookie(NextResponse.json({ error: "Not found" }, { status: 404 }));

    const scheduledPostCount = await prisma.scheduledPost.count({
      where: { threadsAccountId: id, userId },
    });
    const dailyPlanCount = await prisma.dailyTopicPlan.count({
      where: { threadsAccountId: id, userId },
    });

    const force = new URL(req.url).searchParams.get("force") === "1";
    if (!force && (scheduledPostCount > 0 || dailyPlanCount > 0)) {
      return withCookie(
        NextResponse.json(
          {
            error: "이 계정에는 연결된 예약/자동발행 데이터가 있습니다. 강제 삭제(force=1)로만 삭제할 수 있습니다.",
            counts: {
              scheduledPosts: scheduledPostCount,
              dailyTopicPlans: dailyPlanCount,
            },
          },
          { status: 409 }
        )
      );
    }

    await prisma.threadsAccount.delete({
      where: { id },
    });

    return withCookie(
      NextResponse.json({
        ok: true,
        deleted: {
          id: account.id,
          label: account.label,
          threadsUsername: account.threadsUsername,
          threadsUserId: account.threadsUserId,
        },
      })
    );
  } catch (err) {
    const details = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error: details }, { status: 400 }));
  }
}
