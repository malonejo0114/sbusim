import { NextResponse } from "next/server";
import { ScheduledPostStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session, upsertUserById } from "@/server/session";

function monthRange(monthParam?: string) {
  const now = new Date();
  const match = monthParam?.match(/^(\d{4})-(\d{2})$/);
  const year = match ? Number(match[1]) : now.getFullYear();
  const month = match ? Number(match[2]) : now.getMonth() + 1;
  const safeYear = Number.isFinite(year) ? year : now.getFullYear();
  const safeMonth = Number.isFinite(month) && month >= 1 && month <= 12 ? month : now.getMonth() + 1;

  const start = new Date(safeYear, safeMonth - 1, 1, 0, 0, 0, 0);
  const end = new Date(safeYear, safeMonth, 1, 0, 0, 0, 0);
  return {
    month: `${safeYear}-${String(safeMonth).padStart(2, "0")}`,
    start,
    end,
  };
}

function toDateKey(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export async function GET(req: Request) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  try {
    await upsertUserById(userId);

    const url = new URL(req.url);
    const range = monthRange(url.searchParams.get("month") ?? undefined);

    const [accounts, posts] = await Promise.all([
      prisma.threadsAccount.findMany({
        where: { userId },
        orderBy: [{ updatedAt: "desc" }],
        select: {
          id: true,
          label: true,
          threadsUserId: true,
          threadsUsername: true,
          proxyUrlEncrypted: true,
          tokenExpiresAt: true,
          createdAt: true,
          updatedAt: true,
        },
      }),
      prisma.scheduledPost.findMany({
        where: { userId },
        select: {
          id: true,
          threadsAccountId: true,
          status: true,
          scheduledAt: true,
          remotePostId: true,
          viewsCount: true,
          likesCount: true,
          repliesCount: true,
          repostsCount: true,
          quotesCount: true,
        },
      }),
    ]);

    const byAccount = new Map<
      string,
      {
        totalScheduled: number;
        monthlyScheduled: number;
        monthlyPublished: number;
        pending: number;
        running: number;
        success: number;
        failed: number;
        partialFailed: number;
        engagement: {
          views: number;
          likes: number;
          replies: number;
          reposts: number;
          quotes: number;
        };
      }
    >();

    const calendarMap = new Map<
      string,
      {
        total: number;
        byAccount: Map<
          string,
          {
            total: number;
            success: number;
            pending: number;
            failed: number;
          }
        >;
      }
    >();

    for (const post of posts) {
      const current =
        byAccount.get(post.threadsAccountId) ??
        {
          totalScheduled: 0,
          monthlyScheduled: 0,
          monthlyPublished: 0,
          pending: 0,
          running: 0,
          success: 0,
          failed: 0,
          partialFailed: 0,
          engagement: { views: 0, likes: 0, replies: 0, reposts: 0, quotes: 0 },
        };

      current.totalScheduled += 1;
      if (post.status === ScheduledPostStatus.PENDING) current.pending += 1;
      if (post.status === ScheduledPostStatus.RUNNING) current.running += 1;
      if (post.status === ScheduledPostStatus.SUCCESS) current.success += 1;
      if (post.status === ScheduledPostStatus.FAILED) current.failed += 1;
      if (post.status === ScheduledPostStatus.PARTIAL_FAILED) current.partialFailed += 1;

      if (post.remotePostId) {
        current.engagement.views += post.viewsCount;
        current.engagement.likes += post.likesCount;
        current.engagement.replies += post.repliesCount;
        current.engagement.reposts += post.repostsCount;
        current.engagement.quotes += post.quotesCount;
      }

      const inMonth = post.scheduledAt >= range.start && post.scheduledAt < range.end;
      if (inMonth) {
        current.monthlyScheduled += 1;
        if (post.status === ScheduledPostStatus.SUCCESS) {
          current.monthlyPublished += 1;
        }

        const dateKey = toDateKey(post.scheduledAt);
        const dateCurrent = calendarMap.get(dateKey) ?? { total: 0, byAccount: new Map() };
        dateCurrent.total += 1;
        const accountCurrent = dateCurrent.byAccount.get(post.threadsAccountId) ?? {
          total: 0,
          success: 0,
          pending: 0,
          failed: 0,
        };
        accountCurrent.total += 1;
        if (post.status === ScheduledPostStatus.SUCCESS) accountCurrent.success += 1;
        if (post.status === ScheduledPostStatus.PENDING || post.status === ScheduledPostStatus.RUNNING) {
          accountCurrent.pending += 1;
        }
        if (post.status === ScheduledPostStatus.FAILED || post.status === ScheduledPostStatus.PARTIAL_FAILED) {
          accountCurrent.failed += 1;
        }
        dateCurrent.byAccount.set(post.threadsAccountId, accountCurrent);
        calendarMap.set(dateKey, dateCurrent);
      }

      byAccount.set(post.threadsAccountId, current);
    }

    const accountNameMap = new Map<string, string>();
    for (const account of accounts) {
      accountNameMap.set(
        account.id,
        account.label ?? account.threadsUsername ?? account.threadsUserId ?? account.id
      );
    }

    const responseAccounts = accounts.map((account) => {
      const stats =
        byAccount.get(account.id) ??
        {
          totalScheduled: 0,
          monthlyScheduled: 0,
          monthlyPublished: 0,
          pending: 0,
          running: 0,
          success: 0,
          failed: 0,
          partialFailed: 0,
          engagement: { views: 0, likes: 0, replies: 0, reposts: 0, quotes: 0 },
        };

      return {
        id: account.id,
        label: account.label,
        threadsUserId: account.threadsUserId,
        threadsUsername: account.threadsUsername,
        hasProxy: Boolean(account.proxyUrlEncrypted),
        tokenExpiresAt: account.tokenExpiresAt.toISOString(),
        createdAt: account.createdAt.toISOString(),
        updatedAt: account.updatedAt.toISOString(),
        stats,
      };
    });

    const calendarDays = Array.from(calendarMap.entries())
      .map(([date, value]) => ({
        date,
        total: value.total,
        byAccount: Array.from(value.byAccount.entries()).map(([accountId, item]) => ({
          accountId,
          accountName: accountNameMap.get(accountId) ?? accountId,
          ...item,
        })),
      }))
      .sort((a, b) => (a.date < b.date ? -1 : 1));

    return withCookie(
      NextResponse.json({
        month: range.month,
        accounts: responseAccounts,
        calendarDays,
      })
    );
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error }, { status: 500 }));
  }
}
