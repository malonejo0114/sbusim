import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { enqueuePublishJob } from "@/server/queue";
import { MediaType, ScheduledPostStatus } from "@prisma/client";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session, upsertUserById } from "@/server/session";

const CreateScheduledPostSchema = z.object({
  threadsAccountId: z.string().trim().min(1),
  text: z.string().trim().min(1),
  mediaType: z.enum(["TEXT", "IMAGE", "VIDEO"]),
  mediaUrl: z.string().url().optional().or(z.literal("")).transform((v) => (v ? v : undefined)),
  // Accept both RFC3339 and <input type="datetime-local"> values (no timezone).
  scheduledAt: z.string().trim().min(1),
  commentText: z.string().trim().optional().or(z.literal("")).transform((v) => (v ? v : undefined)),
  commentDelaySeconds: z.coerce.number().int().min(0).max(60 * 60 * 24).optional(),
});

function toPublicInfraError(details: string) {
  const d = details.toLowerCase();
  if (d.includes("6379") || d.includes("redis") || d.includes("ioredis") || d.includes("bullmq")) {
    return "Redis 연결 실패: Redis를 실행하세요 (docker compose up -d)";
  }
  if (d.includes("5432") || d.includes("postgres") || d.includes("database") || d.includes("prisma")) {
    return "DB 연결 실패: Postgres를 실행하세요 (docker compose up -d)";
  }
  return "서버 에러가 발생했습니다. (Postgres/Redis 실행 여부를 확인하세요)";
}

export async function GET(req: Request) {
  const { userId, setCookie } = await ensureSessionUserId();
  const url = new URL(req.url);
  const threadsAccountId = url.searchParams.get("threadsAccountId")?.trim() || undefined;

  try {
    await upsertUserById(userId);

    const threadsAccounts = await prisma.threadsAccount.findMany({
      where: { userId },
      orderBy: [{ updatedAt: "desc" }],
    });

    const posts = await prisma.scheduledPost.findMany({
      where: {
        userId,
        ...(threadsAccountId ? { threadsAccountId } : {}),
      },
      orderBy: { scheduledAt: "desc" },
      include: {
        threadsAccount: {
          select: {
            id: true,
            label: true,
            threadsUserId: true,
            threadsUsername: true,
          },
        },
      },
    });

    const res = NextResponse.json({
      threadsAccounts: threadsAccounts.map((acc) => ({
        id: acc.id,
        label: acc.label,
        threadsUserId: acc.threadsUserId,
        threadsUsername: acc.threadsUsername,
        hasProxy: Boolean(acc.proxyUrlEncrypted),
        tokenExpiresAt: acc.tokenExpiresAt.toISOString(),
      })),
      posts: posts.map((p) => ({
        ...p,
        account: p.threadsAccount
          ? {
              id: p.threadsAccount.id,
              label: p.threadsAccount.label,
              threadsUserId: p.threadsAccount.threadsUserId,
              threadsUsername: p.threadsAccount.threadsUsername,
            }
          : null,
        scheduledAt: p.scheduledAt.toISOString(),
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
    });
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  } catch (err) {
    console.error("GET /api/scheduled-posts failed:", err);
    const details = err instanceof Error ? err.message : String(err);
    const error = toPublicInfraError(details);
    const res = NextResponse.json(
      process.env.NODE_ENV === "production" ? { error } : { error, details },
      { status: 500 }
    );
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  }
}

export async function POST(req: Request) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  const json = await req.json().catch(() => null);
  const parsed = CreateScheduledPostSchema.safeParse(json);
  if (!parsed.success) {
    return withCookie(NextResponse.json({ error: parsed.error.flatten() }, { status: 400 }));
  }

  const { threadsAccountId, text, mediaType, mediaUrl, scheduledAt, commentText, commentDelaySeconds } =
    parsed.data;

  if ((mediaType === "IMAGE" || mediaType === "VIDEO") && !mediaUrl) {
    return withCookie(NextResponse.json({ error: "mediaUrl is required for IMAGE/VIDEO" }, { status: 400 }));
  }
  if (mediaType === "TEXT" && mediaUrl) {
    return withCookie(NextResponse.json({ error: "mediaUrl must be empty for TEXT posts" }, { status: 400 }));
  }

  const scheduledAtDate = new Date(scheduledAt);
  if (Number.isNaN(scheduledAtDate.getTime())) {
    return withCookie(NextResponse.json({ error: "Invalid scheduledAt" }, { status: 400 }));
  }

  try {
    await upsertUserById(userId);

    const threadsAccount = await prisma.threadsAccount.findFirst({
      where: { id: threadsAccountId, userId },
    });
    if (!threadsAccount) {
      return withCookie(NextResponse.json({ error: "선택한 Threads 계정을 찾을 수 없습니다." }, { status: 400 }));
    }

    const post = await prisma.scheduledPost.create({
      data: {
        userId,
        threadsAccountId: threadsAccount.id,
        text,
        mediaType: mediaType as MediaType,
        mediaUrl: mediaUrl ?? null,
        commentText: commentText ?? null,
        commentDelaySeconds: commentDelaySeconds ?? 0,
        scheduledAt: scheduledAtDate,
        status: ScheduledPostStatus.PENDING,
      },
    });

    try {
      await enqueuePublishJob({
        scheduledPostId: post.id,
        delayMs: scheduledAtDate.getTime() - Date.now(),
      });
    } catch (err) {
      const details = err instanceof Error ? err.message : String(err);
      await prisma.scheduledPost.update({
        where: { id: post.id },
        data: { status: ScheduledPostStatus.FAILED, lastError: `Enqueue failed: ${details}` },
      });
      const error = toPublicInfraError(details);
      return withCookie(
        NextResponse.json(process.env.NODE_ENV === "production" ? { error } : { error, details }, { status: 500 })
      );
    }

    return withCookie(
      NextResponse.json({
        post: {
          ...post,
          scheduledAt: post.scheduledAt.toISOString(),
          createdAt: post.createdAt.toISOString(),
          updatedAt: post.updatedAt.toISOString(),
        },
      })
    );
  } catch (err) {
    console.error("POST /api/scheduled-posts failed:", err);
    const details = err instanceof Error ? err.message : String(err);
    const error = toPublicInfraError(details);
    return withCookie(
      NextResponse.json(process.env.NODE_ENV === "production" ? { error } : { error, details }, { status: 500 })
    );
  }
}
