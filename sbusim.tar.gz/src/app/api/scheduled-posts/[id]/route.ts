import { NextResponse } from "next/server";
import { ScheduledPostStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { removeScheduledPostJobs } from "@/server/queue";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session, upsertUserById } from "@/server/session";

function toPublicInfraError(details: string) {
  const d = details.toLowerCase();
  if (d.includes("6379") || d.includes("redis") || d.includes("ioredis") || d.includes("bullmq")) {
    return "Redis 연결 실패: Redis를 실행하세요 (docker compose up -d)";
  }
  if (d.includes("5432") || d.includes("postgres") || d.includes("database") || d.includes("prisma")) {
    return "DB 연결 실패: Postgres를 실행하세요 (docker compose up -d)";
  }
  return "서버 에러가 발생했습니다. (Postgres/Redis 실행 여부를 확인하세요)";
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  const { id } = await ctx.params;

  try {
    await upsertUserById(userId);

    const post = await prisma.scheduledPost.findFirst({
      where: { id, userId },
      select: { id: true, status: true, remotePostId: true },
    });
    if (!post) {
      return withCookie(NextResponse.json({ error: "Not found" }, { status: 404 }));
    }

    if (post.status === ScheduledPostStatus.RUNNING) {
      return withCookie(NextResponse.json({ error: "현재 발행 중인 글은 삭제할 수 없습니다." }, { status: 409 }));
    }
    if (post.status === ScheduledPostStatus.SUCCESS || post.remotePostId) {
      return withCookie(NextResponse.json({ error: "이미 발행된 글은 삭제할 수 없습니다." }, { status: 409 }));
    }

    await prisma.scheduledPost.delete({ where: { id: post.id } });

    await removeScheduledPostJobs(post.id).catch((err) => {
      // Even if queue cleanup fails, the deleted row prevents duplicate publishing.
      console.warn("DELETE /api/scheduled-posts/:id queue cleanup failed:", err);
    });

    return withCookie(NextResponse.json({ ok: true }));
  } catch (err) {
    console.error("DELETE /api/scheduled-posts/:id failed:", err);
    const details = err instanceof Error ? err.message : String(err);
    const error = toPublicInfraError(details);
    return withCookie(
      NextResponse.json(process.env.NODE_ENV === "production" ? { error } : { error, details }, { status: 500 })
    );
  }
}
