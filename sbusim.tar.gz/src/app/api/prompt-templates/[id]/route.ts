import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ensureSessionUserId, sessionCookieOptions } from "@/server/sessionRequest";
import { session, upsertUserById } from "@/server/session";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function DELETE(_req: Request, context: RouteContext) {
  const { userId, setCookie } = await ensureSessionUserId();
  const withCookie = (res: NextResponse) => {
    if (setCookie) res.cookies.set(session.cookieName, userId, sessionCookieOptions());
    return res;
  };

  try {
    await upsertUserById(userId);
    const { id } = await context.params;

    const deleted = await prisma.promptTemplate.deleteMany({
      where: { id, userId },
    });
    if (deleted.count === 0) {
      return withCookie(NextResponse.json({ error: "템플릿을 찾을 수 없습니다." }, { status: 404 }));
    }

    return withCookie(NextResponse.json({ ok: true }));
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    return withCookie(NextResponse.json({ error }, { status: 500 }));
  }
}
