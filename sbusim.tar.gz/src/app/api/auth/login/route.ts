import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { authCookieOptions, AUTH_COOKIE_NAME, getDashboardLoginConfig } from "@/server/auth";
import { migrateUserScope, session, sessionCookieOptions, upsertUserById, userIdFromLoginId } from "@/server/session";
import { prisma } from "@/lib/prisma";

const LoginSchema = z.object({
  loginId: z.string().trim().min(1),
  password: z.string().min(1),
});

export async function POST(req: Request) {
  const json = await req.json().catch(() => null);
  const parsed = LoginSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "아이디/비밀번호를 확인해주세요." }, { status: 400 });
  }

  try {
    const config = getDashboardLoginConfig();
    if (parsed.data.loginId !== config.loginId || parsed.data.password !== config.loginPassword) {
      return NextResponse.json({ error: "아이디 또는 비밀번호가 올바르지 않습니다." }, { status: 401 });
    }

    const canonicalUserId = userIdFromLoginId(config.loginId);
    const currentCookieUserId = (await cookies()).get(session.cookieName)?.value;
    await upsertUserById(canonicalUserId);
    if (currentCookieUserId && currentCookieUserId !== canonicalUserId) {
      await migrateUserScope(currentCookieUserId, canonicalUserId);
    } else {
      const canonicalCounts = await prisma.user.findUnique({
        where: { id: canonicalUserId },
        select: {
          _count: {
            select: {
              threadsAccounts: true,
              scheduledPosts: true,
              dailyTopicPlans: true,
              promptTemplates: true,
            },
          },
        },
      });
      const hasCanonicalData = Boolean(
        canonicalCounts &&
          (canonicalCounts._count.threadsAccounts > 0 ||
            canonicalCounts._count.scheduledPosts > 0 ||
            canonicalCounts._count.dailyTopicPlans > 0 ||
            canonicalCounts._count.promptTemplates > 0)
      );

      if (!hasCanonicalData) {
        const candidateUsers = await prisma.user.findMany({
          where: {
            id: { not: canonicalUserId },
            OR: [
              { threadsAccounts: { some: {} } },
              { scheduledPosts: { some: {} } },
              { dailyTopicPlans: { some: {} } },
              { promptTemplates: { some: {} } },
            ],
          },
          select: { id: true },
          orderBy: { createdAt: "asc" },
          take: 2,
        });
        if (candidateUsers.length === 1) {
          await migrateUserScope(candidateUsers[0].id, canonicalUserId);
        }
      }
    }

    const res = NextResponse.json({ ok: true });
    res.cookies.set(AUTH_COOKIE_NAME, crypto.randomUUID(), authCookieOptions());
    res.cookies.set(session.cookieName, canonicalUserId, sessionCookieOptions());
    return res;
  } catch (err) {
    const message = err instanceof Error ? err.message : "로그인 설정이 올바르지 않습니다.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
