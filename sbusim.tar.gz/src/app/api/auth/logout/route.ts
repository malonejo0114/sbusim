import { NextResponse } from "next/server";
import { AUTH_COOKIE_NAME } from "@/server/auth";

function clearAuthCookie(res: NextResponse) {
  res.cookies.set(AUTH_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
  res.cookies.set("sbusim_uid", "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
  return res;
}

export async function POST() {
  return clearAuthCookie(NextResponse.json({ ok: true }));
}

export async function GET(req: Request) {
  const origin = new URL(req.url).origin;
  return clearAuthCookie(NextResponse.redirect(new URL("/login", origin)));
}
