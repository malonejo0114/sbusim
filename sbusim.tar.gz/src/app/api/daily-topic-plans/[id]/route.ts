import { NextResponse } from "next/server";

const DISABLED_MESSAGE = "자동발행 플랜 기능은 현재 비활성화되었습니다.";

export async function PATCH() {
  return NextResponse.json({ error: DISABLED_MESSAGE }, { status: 410 });
}

export async function DELETE() {
  return NextResponse.json({ error: DISABLED_MESSAGE }, { status: 410 });
}
