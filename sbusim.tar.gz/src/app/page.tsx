import Link from "next/link";
import { cookies } from "next/headers";
import { AUTH_COOKIE_NAME } from "@/server/auth";

export default async function Home() {
  const store = await cookies();
  const isAuthed = Boolean(store.get(AUTH_COOKIE_NAME)?.value);

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-50 via-white to-zinc-100 text-zinc-950">
      <main className="mx-auto max-w-5xl px-6 py-20">
        <div className="flex items-start justify-between gap-6">
          <div>
            <div className="inline-flex items-center rounded-full border border-zinc-200 bg-white/70 px-3 py-1 text-sm text-zinc-700 shadow-sm backdrop-blur">
              Threads Scheduler MVP
            </div>
            <h1 className="mt-6 text-4xl font-semibold tracking-tight sm:text-5xl">
              스부심(SBUSIM)
            </h1>
            <p className="mt-4 max-w-2xl text-lg leading-8 text-zinc-700">
              Threads 공식 Graph API로만 작동하는 예약 발행 + 첫 댓글 자동화 도구.
            </p>
          </div>
          <Link
            href={isAuthed ? "/dashboard" : "/login"}
            className="inline-flex h-11 items-center justify-center rounded-full bg-zinc-950 px-5 text-sm font-medium text-white shadow-sm hover:bg-zinc-800"
          >
            {isAuthed ? "대시보드로 이동" : "로그인"}
          </Link>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <h2 className="text-base font-semibold">MVP 기능</h2>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-700">
              <li>Threads OAuth 연결</li>
              <li>텍스트 + (옵션) 이미지/영상 URL 게시</li>
              <li>발행 시간 예약 및 서버 워커 발행</li>
              <li>발행 직후 또는 지연 후 첫 댓글(reply) 자동 작성</li>
              <li>예약 목록/상태 확인 및 실패 재시도</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <h2 className="text-base font-semibold">중요 제약</h2>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-700">
              <li>스크래핑/비공식 자동화 금지 (공식 API만)</li>
              <li>컨테이너 생성 → publish 패턴 준수</li>
              <li>댓글은 reply_to_id로 구현</li>
              <li>access_token은 DB에 AES-GCM으로 암호화 저장</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 text-sm text-zinc-600">
          로컬 실행 방법은 <code className="rounded bg-zinc-100 px-1.5 py-0.5">README.md</code>를 참고하세요.
        </div>
      </main>
    </div>
  );
}
