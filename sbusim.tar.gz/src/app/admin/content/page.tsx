import DashboardShell from "@/app/dashboard/_components/DashboardShell";

export const dynamic = "force-dynamic";

export default function AdminContentPage() {
  return (
    <DashboardShell
      title="콘텐츠 자동화"
      subtitle="메타 리뷰 대응을 위해 차트/뉴스 자동 생성 기능은 비활성화되었습니다."
      showBackToDashboard
    >
      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-base font-semibold text-slate-900">기능 비활성화</h2>
        <p className="mt-2 text-sm text-slate-600">
          차트 렌더링, 뉴스/RSS 수집, 크론 기반 자동 생성 기능은 현재 제공하지 않습니다.
        </p>
      </section>
    </DashboardShell>
  );
}
