"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";

type OverviewAccount = {
  id: string;
  label: string | null;
  threadsUserId: string | null;
  threadsUsername: string | null;
  hasProxy: boolean;
  tokenExpiresAt: string;
  stats: {
    totalScheduled: number;
    monthlyScheduled: number;
    monthlyPublished: number;
    pending: number;
    running: number;
    success: number;
    failed: number;
    partialFailed: number;
    engagement: {
      views: number;
      likes: number;
      replies: number;
      reposts: number;
      quotes: number;
    };
  };
};

type CalendarItem = {
  date: string;
  total: number;
  byAccount: Array<{
    accountId: string;
    accountName: string;
    total: number;
    success: number;
    pending: number;
    failed: number;
  }>;
};

type OverviewResponse = {
  month: string;
  accounts: OverviewAccount[];
  calendarDays: CalendarItem[];
};

function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(month: string) {
  const [y, m] = month.split("-").map((v) => Number(v));
  return `${y}년 ${m}월`;
}

function shiftMonth(month: string, delta: number) {
  const [y, m] = month.split("-").map((v) => Number(v));
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function buildCalendarCells(month: string) {
  const [y, m] = month.split("-").map((v) => Number(v));
  const firstDay = new Date(y, m - 1, 1);
  const start = new Date(firstDay);
  start.setDate(firstDay.getDate() - firstDay.getDay());

  return Array.from({ length: 42 }).map((_, idx) => {
    const d = new Date(start);
    d.setDate(start.getDate() + idx);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    return {
      key,
      day: d.getDate(),
      inMonth: d.getMonth() === m - 1,
    };
  });
}

export default function ManagementClient() {
  const [month, setMonth] = useState(currentMonthKey);
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [selectedDay, setSelectedDay] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  });

  const load = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/dashboard/overview?month=${month}`, { cache: "no-store" });
      const json = (await res.json()) as OverviewResponse | { error?: string };
      if (!res.ok) throw new Error((json as { error?: string }).error ?? "개요를 불러오지 못했습니다.");
      setData(json as OverviewResponse);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }, [month]);

  useEffect(() => {
    void load();
  }, [load]);

  const calendarMap = useMemo(() => {
    const map = new Map<string, CalendarItem>();
    for (const item of data?.calendarDays ?? []) {
      map.set(item.date, item);
    }
    return map;
  }, [data?.calendarDays]);

  const selectedSummary = calendarMap.get(selectedDay);
  const cells = useMemo(() => buildCalendarCells(month), [month]);

  const totalOverview = useMemo(() => {
    const accounts = data?.accounts ?? [];
    return {
      accounts: accounts.length,
      monthlyScheduled: accounts.reduce((sum, acc) => sum + acc.stats.monthlyScheduled, 0),
      monthlyPublished: accounts.reduce((sum, acc) => sum + acc.stats.monthlyPublished, 0),
      pending: accounts.reduce((sum, acc) => sum + acc.stats.pending + acc.stats.running, 0),
      failed: accounts.reduce((sum, acc) => sum + acc.stats.failed + acc.stats.partialFailed, 0),
      views: accounts.reduce((sum, acc) => sum + acc.stats.engagement.views, 0),
      likes: accounts.reduce((sum, acc) => sum + acc.stats.engagement.likes, 0),
      replies: accounts.reduce((sum, acc) => sum + acc.stats.engagement.replies, 0),
      reposts: accounts.reduce((sum, acc) => sum + acc.stats.engagement.reposts, 0),
    };
  }, [data?.accounts]);

  return (
    <div className="space-y-8">
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">연결 계정</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.accounts}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">이번 달 예약</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.monthlyScheduled}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">이번 달 발행 성공</div>
          <div className="mt-1 text-2xl font-semibold text-emerald-700">{totalOverview.monthlyPublished}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">대기/진행</div>
          <div className="mt-1 text-2xl font-semibold text-amber-700">{totalOverview.pending}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">실패/부분실패</div>
          <div className="mt-1 text-2xl font-semibold text-rose-700">{totalOverview.failed}</div>
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">계정별 워크스페이스</h2>
            <p className="mt-1 text-sm text-slate-600">글 작성은 계정 카드를 클릭해서 진입한 상세 페이지에서만 진행합니다.</p>
          </div>
          <a
            className="inline-flex h-10 items-center justify-center rounded-full bg-slate-900 px-5 text-sm font-medium text-white hover:bg-slate-800"
            href="/api/auth/threads/start"
          >
            Threads 계정 추가 연결
          </a>
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
          {(data?.accounts ?? []).map((acc) => {
            const name = acc.label ?? acc.threadsUsername ?? acc.threadsUserId ?? acc.id;
            return (
              <Link
                key={acc.id}
                href={`/dashboard/accounts/${acc.id}`}
                className="group rounded-2xl border border-slate-200 bg-slate-50 p-4 transition hover:border-blue-300 hover:bg-white"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-base font-semibold text-slate-900">{name}</div>
                    <div className="mt-1 text-xs text-slate-500">@{acc.threadsUsername ?? "-"} · uid {acc.threadsUserId ?? "-"}</div>
                  </div>
                  <span className="rounded-full bg-blue-100 px-2.5 py-1 text-[11px] font-semibold text-blue-700 group-hover:bg-blue-600 group-hover:text-white">
                    열기
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                    <div className="text-slate-500">이번달 예약</div>
                    <div className="mt-1 text-sm font-semibold text-slate-900">{acc.stats.monthlyScheduled}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                    <div className="text-slate-500">이번달 발행</div>
                    <div className="mt-1 text-sm font-semibold text-emerald-700">{acc.stats.monthlyPublished}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                    <div className="text-slate-500">대기/진행</div>
                    <div className="mt-1 text-sm font-semibold text-amber-700">{acc.stats.pending + acc.stats.running}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                    <div className="text-slate-500">실패/부분실패</div>
                    <div className="mt-1 text-sm font-semibold text-rose-700">{acc.stats.failed + acc.stats.partialFailed}</div>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-slate-600">
                  <span className="rounded-full bg-slate-200 px-2 py-1">프록시 {acc.hasProxy ? "설정" : "미설정"}</span>
                  <span className="rounded-full bg-slate-200 px-2 py-1">조회 {acc.stats.engagement.views}</span>
                  <span className="rounded-full bg-slate-200 px-2 py-1">좋아요 {acc.stats.engagement.likes}</span>
                </div>
              </Link>
            );
          })}
          {(data?.accounts ?? []).length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-600">
              아직 계정이 없습니다. 상단의 &quot;Threads 계정 추가 연결&quot; 버튼으로 시작하세요.
            </div>
          ) : null}
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">월간 발행 캘린더</h2>
            <p className="mt-1 text-sm text-slate-600">날짜를 클릭하면 계정별 예약/성공/실패 수를 확인할 수 있습니다.</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setMonth((prev) => shiftMonth(prev, -1))}
              className="h-9 rounded-full border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
              disabled={busy}
            >
              이전달
            </button>
            <div className="min-w-28 text-center text-sm font-semibold text-slate-800">{monthLabel(month)}</div>
            <button
              type="button"
              onClick={() => setMonth((prev) => shiftMonth(prev, 1))}
              className="h-9 rounded-full border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
              disabled={busy}
            >
              다음달
            </button>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-7 gap-2 text-center text-xs font-semibold text-slate-500">
          {["일", "월", "화", "수", "목", "금", "토"].map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>
        <div className="mt-2 grid grid-cols-7 gap-2">
          {cells.map((cell) => {
            const summary = calendarMap.get(cell.key);
            return (
              <button
                key={cell.key}
                type="button"
                onClick={() => setSelectedDay(cell.key)}
                className={`min-h-[86px] rounded-xl border px-2 py-2 text-left transition ${
                  cell.inMonth ? "border-slate-200 bg-white" : "border-slate-100 bg-slate-50 text-slate-400"
                } ${selectedDay === cell.key ? "ring-2 ring-blue-500" : "hover:border-slate-300"}`}
              >
                <div className="text-xs font-semibold">{cell.day}</div>
                <div className="mt-2 text-[11px] text-slate-600">{summary ? `총 ${summary.total}건` : ""}</div>
                {summary?.byAccount?.[0] ? (
                  <div className="mt-1 truncate text-[10px] text-slate-500">{summary.byAccount[0].accountName}</div>
                ) : null}
              </button>
            );
          })}
        </div>

        <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="text-sm font-semibold text-slate-900">{selectedDay} 계정별 현황</div>
          <div className="mt-3 space-y-2">
            {(selectedSummary?.byAccount ?? []).map((item) => (
              <div key={item.accountId} className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                <div className="text-sm font-medium text-slate-900">{item.accountName}</div>
                <div className="mt-1 text-xs text-slate-600">
                  예약 {item.total} · 성공 {item.success} · 대기 {item.pending} · 실패 {item.failed}
                </div>
              </div>
            ))}
            {!selectedSummary ? (
              <div className="text-xs text-slate-500">선택한 날짜의 예약 데이터가 없습니다.</div>
            ) : null}
          </div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">누적 조회수</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.views.toLocaleString()}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">누적 좋아요</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.likes.toLocaleString()}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">누적 댓글</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.replies.toLocaleString()}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">누적 리포스트</div>
          <div className="mt-1 text-2xl font-semibold text-slate-900">{totalOverview.reposts.toLocaleString()}</div>
        </div>
      </section>

      {error ? <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}
    </div>
  );
}
