"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type ThreadsAccount = {
  id: string;
  label: string | null;
  threadsUserId: string | null;
  threadsUsername: string | null;
  hasProxy: boolean;
  tokenExpiresAt: string;
};

type PostAccount = {
  id: string;
  label: string | null;
  threadsUserId: string | null;
  threadsUsername: string | null;
};

type ScheduledPost = {
  id: string;
  text: string;
  mediaType: "TEXT" | "IMAGE" | "VIDEO";
  mediaUrl: string | null;
  commentText: string | null;
  commentDelaySeconds: number;
  scheduledAt: string;
  status: "PENDING" | "RUNNING" | "SUCCESS" | "FAILED" | "PARTIAL_FAILED";
  remotePostId: string | null;
  remoteCommentId: string | null;
  viewsCount: number;
  likesCount: number;
  repliesCount: number;
  repostsCount: number;
  quotesCount: number;
  insightsUpdatedAt: string | null;
  insightsLastError: string | null;
  lastError: string | null;
  createdAt: string;
  updatedAt: string;
  account: PostAccount | null;
};

type PromptTemplate = {
  id: string;
  name: string;
  prompt: string;
  createdAt: string;
  updatedAt: string;
};

type GeneratedDraft = {
  id: string;
  text: string;
  firstComment: string;
  scheduledAt: string;
};

function toDatetimeLocalValue(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  const yyyy = d.getFullYear();
  const mm = pad(d.getMonth() + 1);
  const dd = pad(d.getDate());
  const hh = pad(d.getHours());
  const mi = pad(d.getMinutes());
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
}

function badgeClasses(status: ScheduledPost["status"]) {
  switch (status) {
    case "PENDING":
      return "bg-slate-100 text-slate-700 border-slate-200";
    case "RUNNING":
      return "bg-blue-50 text-blue-700 border-blue-200";
    case "SUCCESS":
      return "bg-emerald-50 text-emerald-700 border-emerald-200";
    case "FAILED":
      return "bg-rose-50 text-rose-700 border-rose-200";
    case "PARTIAL_FAILED":
      return "bg-amber-50 text-amber-800 border-amber-200";
    default:
      return "bg-slate-100 text-slate-700 border-slate-200";
  }
}

type Tab = "content" | "performance" | "settings";

export default function AccountWorkspaceClient({ accountId }: { accountId: string }) {
  const router = useRouter();
  const didInitialLoad = useRef(false);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("content");

  const [threadsAccounts, setThreadsAccounts] = useState<ThreadsAccount[]>([]);
  const [account, setAccount] = useState<ThreadsAccount | null>(null);
  const [posts, setPosts] = useState<ScheduledPost[]>([]);
  const [promptTemplates, setPromptTemplates] = useState<PromptTemplate[]>([]);

  const [accountLabel, setAccountLabel] = useState("");
  const [proxyUrl, setProxyUrl] = useState("");

  const defaultScheduledAt = useMemo(() => toDatetimeLocalValue(new Date(Date.now() + 5 * 60 * 1000)), []);

  const [text, setText] = useState("");
  const [mediaType, setMediaType] = useState<ScheduledPost["mediaType"]>("TEXT");
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [scheduledAt, setScheduledAt] = useState(defaultScheduledAt);
  const [commentText, setCommentText] = useState("");
  const [commentDelaySeconds, setCommentDelaySeconds] = useState("0");

  const [templateName, setTemplateName] = useState("");
  const [templatePrompt, setTemplatePrompt] = useState("");
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [issuePrompt, setIssuePrompt] = useState("오늘 이슈 시황 알려줘");
  const [extraPrompt, setExtraPrompt] = useState("");
  const [generateCount, setGenerateCount] = useState("3");
  const [draftIntervalMinutes, setDraftIntervalMinutes] = useState("60");
  const [briefing, setBriefing] = useState("");
  const [generatedDrafts, setGeneratedDrafts] = useState<GeneratedDraft[]>([]);
  const [generationError, setGenerationError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setBusy(true);
    setError(null);

    try {
      const [accountRes, postsRes, templatesRes] = await Promise.all([
        fetch(`/api/threads-accounts/${accountId}`, { method: "GET", cache: "no-store" }),
        fetch(`/api/scheduled-posts?threadsAccountId=${accountId}`, { method: "GET", cache: "no-store" }),
        fetch("/api/prompt-templates", { method: "GET", cache: "no-store" }),
      ]);

      const accountData = await accountRes.json();
      if (!accountRes.ok) throw new Error(accountData?.error ?? "계정 정보를 불러오지 못했습니다.");

      const postsData = await postsRes.json();
      if (!postsRes.ok) throw new Error(postsData?.error ?? "예약 목록을 불러오지 못했습니다.");

      const templatesData = await templatesRes.json();
      if (!templatesRes.ok) throw new Error(templatesData?.error ?? "템플릿을 불러오지 못했습니다.");

      const loadedAccount = accountData?.account as ThreadsAccount | undefined;
      if (!loadedAccount) throw new Error("계정을 찾을 수 없습니다.");

      setAccount(loadedAccount);
      setAccountLabel(loadedAccount.label ?? loadedAccount.threadsUsername ?? "");
      setThreadsAccounts((postsData?.threadsAccounts as ThreadsAccount[]) ?? []);
      setPosts((postsData?.posts as ScheduledPost[]) ?? []);

      const templates = (templatesData?.templates as PromptTemplate[]) ?? [];
      setPromptTemplates(templates);
      if (selectedTemplateId && !templates.some((tpl) => tpl.id === selectedTemplateId)) {
        setSelectedTemplateId("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }, [accountId, selectedTemplateId]);

  useEffect(() => {
    if (didInitialLoad.current) return;
    didInitialLoad.current = true;
    void refresh();
  }, [refresh]);

  async function uploadMedia(file: File): Promise<string> {
    const form = new FormData();
    form.append("file", file);
    const res = await fetch("/api/uploads/media", {
      method: "POST",
      body: form,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error ?? "업로드 실패");
    if (!data?.url) throw new Error("업로드 URL이 비어 있습니다.");
    return data.url as string;
  }

  async function createScheduledPost(targetScheduledAt: string) {
    let resolvedMediaUrl = mediaUrl.trim() || undefined;
    if ((mediaType === "IMAGE" || mediaType === "VIDEO") && !resolvedMediaUrl && mediaFile) {
      resolvedMediaUrl = await uploadMedia(mediaFile);
      setMediaUrl(resolvedMediaUrl);
    }

    const payload = {
      threadsAccountId: accountId,
      text,
      mediaType,
      mediaUrl: resolvedMediaUrl,
      scheduledAt: (() => {
        const d = new Date(targetScheduledAt);
        return Number.isNaN(d.getTime()) ? targetScheduledAt : d.toISOString();
      })(),
      commentText: commentText || undefined,
      commentDelaySeconds: Number(commentDelaySeconds || "0"),
    };

    const res = await fetch("/api/scheduled-posts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error?.formErrors?.[0] ?? data?.error ?? "예약 생성 실패");
  }

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await createScheduledPost(scheduledAt);
      setText("");
      setMediaUrl("");
      setMediaFile(null);
      setCommentText("");
      setCommentDelaySeconds("0");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onPublishNow() {
    setBusy(true);
    setError(null);
    try {
      await createScheduledPost(new Date().toISOString());
      setText("");
      setMediaUrl("");
      setMediaFile(null);
      setCommentText("");
      setCommentDelaySeconds("0");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onRetry(id: string) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/scheduled-posts/${id}/retry`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "재시도 실패");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onDeleteScheduledPost(post: ScheduledPost) {
    const ok = window.confirm("이 예약 글을 삭제할까요? 삭제 후 복구할 수 없습니다.");
    if (!ok) return;

    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/scheduled-posts/${post.id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "예약 삭제 실패");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onSaveAccountSettings() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/threads-accounts/${accountId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ label: accountLabel, proxyUrl: proxyUrl || "" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "계정 설정 저장 실패");
      setProxyUrl("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onDeleteAccount() {
    if (!account) return;

    const name = account.label ?? account.threadsUsername ?? account.threadsUserId ?? account.id;
    const firstConfirm = window.confirm(`Threads 계정 "${name}"을 삭제할까요?`);
    if (!firstConfirm) return;

    setBusy(true);
    setError(null);
    try {
      let res = await fetch(`/api/threads-accounts/${accountId}`, { method: "DELETE" });
      let data = await res.json();

      if (res.status === 409) {
        const scheduled = Number(data?.counts?.scheduledPosts ?? 0);
        const secondConfirm = window.confirm(`이 계정에 연결된 예약 ${scheduled}건과 관련 데이터가 함께 삭제됩니다. 계속할까요?`);
        if (!secondConfirm) return;

        res = await fetch(`/api/threads-accounts/${accountId}?force=1`, { method: "DELETE" });
        data = await res.json();
      }

      if (!res.ok) throw new Error(data?.error ?? "계정 삭제 실패");
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onCreateTemplate(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/prompt-templates", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: templateName, prompt: templatePrompt }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.formErrors?.[0] ?? data?.error ?? "템플릿 생성 실패");
      setTemplateName("");
      setTemplatePrompt("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onDeleteTemplate(id: string) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/prompt-templates/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "템플릿 삭제 실패");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onGeneratePosts() {
    setBusy(true);
    setError(null);
    setGenerationError(null);
    try {
      if (!issuePrompt.trim()) throw new Error("이슈 질의를 입력하세요.");
      const selectedTemplate = promptTemplates.find((tpl) => tpl.id === selectedTemplateId);

      const res = await fetch("/api/content-generation", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          issuePrompt,
          templatePrompt: selectedTemplate?.prompt ?? undefined,
          extraPrompt: extraPrompt || undefined,
          count: Number(generateCount || "1"),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "글 생성 실패");

      setBriefing((data?.briefing as string) ?? "");
      const intervalMinutes = Math.max(0, Math.min(24 * 60, Number(draftIntervalMinutes || "60")));
      const base = new Date(Date.now() + 10 * 60 * 1000);
      setGeneratedDrafts(
        ((data?.posts as Array<{ text?: string; firstComment?: string }>) ?? []).map((item, idx) => ({
          id: `${Date.now()}-${idx}`,
          text: item.text?.trim() ?? "",
          firstComment: item.firstComment?.trim() ?? "",
          scheduledAt: toDatetimeLocalValue(new Date(base.getTime() + idx * intervalMinutes * 60 * 1000)),
        }))
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setGenerationError(message);
      setError(message);
    } finally {
      setBusy(false);
    }
  }

  function updateDraft(id: string, patch: Partial<GeneratedDraft>) {
    setGeneratedDrafts((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));
  }

  async function onScheduleDraft(draft: GeneratedDraft) {
    setBusy(true);
    setError(null);
    setGenerationError(null);
    try {
      const res = await fetch("/api/scheduled-posts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          threadsAccountId: accountId,
          text: draft.text,
          mediaType: "TEXT",
          scheduledAt: (() => {
            const d = new Date(draft.scheduledAt);
            return Number.isNaN(d.getTime()) ? draft.scheduledAt : d.toISOString();
          })(),
          commentText: draft.firstComment || undefined,
          commentDelaySeconds: 0,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.formErrors?.[0] ?? data?.error ?? "예약 발행 등록 실패");
      setGeneratedDrafts((prev) => prev.filter((d) => d.id !== draft.id));
      await refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setGenerationError(message);
      setError(message);
    } finally {
      setBusy(false);
    }
  }

  async function onSyncInsights(force = false) {
    setBusy(true);
    setError(null);
    try {
      const params = new URLSearchParams({ threadsAccountId: accountId });
      if (force) params.set("force", "1");
      const res = await fetch(`/api/insights/sync?${params.toString()}`, {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "성과 동기화 실패");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const localFilePreview = useMemo(() => {
    if (!mediaFile) return null;
    return URL.createObjectURL(mediaFile);
  }, [mediaFile]);

  useEffect(() => {
    return () => {
      if (localFilePreview) URL.revokeObjectURL(localFilePreview);
    };
  }, [localFilePreview]);

  const previewMediaUrl = mediaUrl.trim() || localFilePreview || "";

  const performanceSummary = useMemo(() => {
    return posts.reduce(
      (acc, post) => {
        acc.views += post.viewsCount;
        acc.likes += post.likesCount;
        acc.replies += post.repliesCount;
        acc.reposts += post.repostsCount;
        acc.quotes += post.quotesCount;
        return acc;
      },
      { views: 0, likes: 0, replies: 0, reposts: 0, quotes: 0 }
    );
  }, [posts]);

  const topPosts = useMemo(() => {
    const score = (p: ScheduledPost) => p.viewsCount + p.likesCount * 3 + p.repliesCount * 4 + p.repostsCount * 5;
    return [...posts]
      .filter((p) => Boolean(p.remotePostId))
      .sort((a, b) => score(b) - score(a))
      .slice(0, 10);
  }, [posts]);

  const accountName = account?.label ?? account?.threadsUsername ?? account?.threadsUserId ?? accountId;

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-xs font-medium uppercase tracking-wider text-slate-500">Account Workspace</div>
            <div className="mt-1 text-2xl font-semibold text-slate-950">{accountName}</div>
            <div className="mt-1 text-sm text-slate-600">
              @{account?.threadsUsername ?? "-"} · uid {account?.threadsUserId ?? "-"} · token 만료 {account ? new Date(account.tokenExpiresAt).toLocaleString() : "-"}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={refresh}
              disabled={busy}
              className="inline-flex h-10 items-center justify-center rounded-full border border-slate-200 px-4 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
            >
              새로고침
            </button>
            <a
              href="/api/auth/threads/start"
              className="inline-flex h-10 items-center justify-center rounded-full bg-slate-900 px-4 text-sm font-medium text-white hover:bg-slate-800"
            >
              계정 추가 연결
            </a>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {threadsAccounts.map((acc) => (
            <Link
              key={acc.id}
              href={`/dashboard/accounts/${acc.id}`}
              className={`inline-flex h-8 items-center rounded-full border px-3 text-xs font-medium transition ${
                acc.id === accountId
                  ? "border-blue-600 bg-blue-600 text-white"
                  : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
              }`}
            >
              {acc.label ?? acc.threadsUsername ?? acc.threadsUserId ?? acc.id}
            </Link>
          ))}
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-3 shadow-sm">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {([
            ["content", "콘텐츠"],
            ["performance", "성과"],
            ["settings", "설정"],
          ] as Array<[Tab, string]>).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`h-11 rounded-2xl text-sm font-semibold transition ${
                tab === key ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </section>

      {tab === "content" ? (
        <div className="space-y-6">
          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900">예약 작성</h2>
            <p className="mt-1 text-sm text-slate-600">이 계정으로만 예약/바로발행 됩니다.</p>

            <form onSubmit={onCreate} className="mt-5 grid gap-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">본문 (필수)</label>
                <textarea
                  className="min-h-28 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  disabled={busy}
                  placeholder="Threads 본문을 입력하세요"
                  required
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">미디어 타입</label>
                  <select
                    className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                    value={mediaType}
                    onChange={(e) => setMediaType(e.target.value as ScheduledPost["mediaType"])}
                    disabled={busy}
                  >
                    <option value="TEXT">TEXT</option>
                    <option value="IMAGE">IMAGE</option>
                    <option value="VIDEO">VIDEO</option>
                  </select>
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">미디어 파일(옵션)</label>
                  <input
                    type="file"
                    className="h-10 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400"
                    disabled={busy || mediaType === "TEXT"}
                    accept={mediaType === "VIDEO" ? "video/*" : "image/*"}
                    onChange={(e) => setMediaFile(e.target.files?.[0] ?? null)}
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">미디어 URL (옵션)</label>
                  <input
                    className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                    disabled={busy || mediaType === "TEXT"}
                    placeholder={mediaType === "TEXT" ? "TEXT는 미디어 없음" : "https://..."}
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">예약 시간</label>
                  <input
                    type="datetime-local"
                    className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                    value={scheduledAt}
                    onChange={(e) => setScheduledAt(e.target.value)}
                    disabled={busy}
                    required
                  />
                </div>
                <div className="grid gap-2 sm:col-span-2">
                  <label className="text-sm font-medium">첫 댓글 (옵션)</label>
                  <input
                    className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    disabled={busy}
                    placeholder="원글 발행 직후/지연 후 자동 댓글"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">댓글 지연(초)</label>
                  <input
                    type="number"
                    min={0}
                    className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                    value={commentDelaySeconds}
                    onChange={(e) => setCommentDelaySeconds(e.target.value)}
                    disabled={busy}
                  />
                </div>
                <div className="sm:col-span-2">
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div className="text-xs font-semibold text-slate-500">발행 전 미리보기</div>
                    <div className="mt-2 rounded-xl border border-slate-200 bg-white p-4">
                      <div className="text-xs text-slate-500">
                        @{account?.threadsUsername ?? "계정"} ·{" "}
                        {scheduledAt ? new Date(scheduledAt).toLocaleString() : "예약 시간 미정"}
                      </div>
                      <div className="mt-3 whitespace-pre-wrap text-sm text-slate-900">
                        {text.trim() || "본문을 입력하면 여기에 미리보기가 표시됩니다."}
                      </div>
                      {mediaType !== "TEXT" && previewMediaUrl ? (
                        mediaType === "VIDEO" ? (
                          <video className="mt-3 max-h-72 w-full rounded-lg border border-slate-200" controls src={previewMediaUrl} />
                        ) : (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={previewMediaUrl}
                            alt="미디어 미리보기"
                            className="mt-3 max-h-72 w-full rounded-lg border border-slate-200 object-contain"
                          />
                        )
                      ) : null}
                      {commentText.trim() ? (
                        <div className="mt-3 rounded-lg border border-blue-100 bg-blue-50 px-3 py-2 text-xs text-blue-800">
                          첫 댓글 미리보기: {commentText}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-end gap-2">
                  <button
                    type="submit"
                    className="inline-flex h-10 items-center justify-center rounded-full bg-slate-900 px-5 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
                    disabled={busy}
                  >
                    예약 생성
                  </button>
                  <button
                    type="button"
                    onClick={onPublishNow}
                    className="inline-flex h-10 items-center justify-center rounded-full border border-slate-300 bg-white px-5 text-sm font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50"
                    disabled={busy}
                  >
                    바로 발행
                  </button>
              </div>
            </form>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900">이슈 기반 글 생성 (AI)</h2>
            <p className="mt-1 text-sm text-slate-600">생성된 초안을 바로 이 계정의 예약으로 전환할 수 있습니다.</p>

            <div className="mt-5 grid gap-6 lg:grid-cols-2">
              <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <h3 className="text-sm font-semibold text-slate-900">프롬프트 템플릿 관리</h3>
                <form onSubmit={onCreateTemplate} className="grid gap-3">
                  <input
                    className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                    placeholder="템플릿 이름"
                    disabled={busy}
                    required
                  />
                  <textarea
                    className="min-h-24 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400"
                    value={templatePrompt}
                    onChange={(e) => setTemplatePrompt(e.target.value)}
                    placeholder="글 생성 지시문"
                    disabled={busy}
                    required
                  />
                  <button
                    type="submit"
                    className="inline-flex h-9 items-center justify-center rounded-full bg-slate-900 px-4 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
                    disabled={busy}
                  >
                    템플릿 저장
                  </button>
                </form>

                <div className="space-y-2">
                  {promptTemplates.map((tpl) => (
                    <div key={tpl.id} className="rounded-xl border border-slate-200 bg-white p-3">
                      <div className="flex items-center justify-between gap-2">
                        <button
                          type="button"
                          className={`text-left text-sm font-semibold ${
                            selectedTemplateId === tpl.id ? "text-blue-700" : "text-slate-900"
                          }`}
                          onClick={() => setSelectedTemplateId((prev) => (prev === tpl.id ? "" : tpl.id))}
                        >
                          {tpl.name}
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteTemplate(tpl.id)}
                          className="text-xs text-rose-600 hover:text-rose-700"
                          disabled={busy}
                        >
                          삭제
                        </button>
                      </div>
                      <div className="mt-2 line-clamp-2 text-xs text-slate-600">{tpl.prompt}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <h3 className="text-sm font-semibold text-slate-900">글 생성</h3>
                <div className="grid gap-3">
                  <input
                    className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
                    value={issuePrompt}
                    onChange={(e) => setIssuePrompt(e.target.value)}
                    disabled={busy}
                    placeholder="예: 오늘 이슈 시황 알려줘"
                  />
                  <textarea
                    className="min-h-24 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400"
                    value={extraPrompt}
                    onChange={(e) => setExtraPrompt(e.target.value)}
                    disabled={busy}
                    placeholder="추가 요청사항"
                  />
                  <div className="grid gap-3 sm:grid-cols-3">
                    <select
                      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
                      value={selectedTemplateId}
                      onChange={(e) => setSelectedTemplateId(e.target.value)}
                      disabled={busy}
                    >
                      <option value="">템플릿 미사용</option>
                      {promptTemplates.map((tpl) => (
                        <option key={tpl.id} value={tpl.id}>
                          {tpl.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min={1}
                      max={10}
                      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
                      value={generateCount}
                      onChange={(e) => setGenerateCount(e.target.value)}
                      disabled={busy}
                    />
                    <input
                      type="number"
                      min={0}
                      max={1440}
                      className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
                      value={draftIntervalMinutes}
                      onChange={(e) => setDraftIntervalMinutes(e.target.value)}
                      disabled={busy}
                      placeholder="초안 간격(분)"
                      title="생성된 초안 예약시간 간격(분)"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={onGeneratePosts}
                    disabled={busy}
                    className="inline-flex h-10 items-center justify-center rounded-full bg-blue-600 px-5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50"
                  >
                    글 생성하기
                  </button>
                  {generationError ? (
                    <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
                      {generationError}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>

            {briefing ? (
              <div className="mt-5 rounded-xl border border-sky-200 bg-sky-50 p-4">
                <div className="text-xs font-semibold text-sky-700">오늘 이슈 브리핑</div>
                <div className="mt-2 whitespace-pre-wrap text-sm text-sky-900">{briefing}</div>
              </div>
            ) : null}

            {generatedDrafts.length > 0 ? (
              <div className="mt-5 grid gap-3">
                {generatedDrafts.map((draft, idx) => (
                  <div key={draft.id} className="rounded-xl border border-slate-200 p-4">
                    <div className="mb-3 text-xs font-semibold text-slate-500">초안 {idx + 1}</div>
                    <div className="grid gap-3">
                      <textarea
                        className="min-h-24 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400"
                        value={draft.text}
                        onChange={(e) => updateDraft(draft.id, { text: e.target.value })}
                        disabled={busy}
                      />
                      <input
                        className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                        value={draft.firstComment}
                        onChange={(e) => updateDraft(draft.id, { firstComment: e.target.value })}
                        placeholder="첫 댓글(옵션)"
                        disabled={busy}
                      />
                      <div className="flex flex-wrap items-center gap-3">
                        <input
                          type="datetime-local"
                          className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                          value={draft.scheduledAt}
                          onChange={(e) => updateDraft(draft.id, { scheduledAt: e.target.value })}
                          disabled={busy}
                        />
                        <button
                          type="button"
                          onClick={() => onScheduleDraft(draft)}
                          disabled={busy || !draft.text.trim()}
                          className="inline-flex h-10 items-center justify-center rounded-full bg-slate-900 px-5 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
                        >
                          예약발행
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}
          </section>
        </div>
      ) : null}

      {tab === "performance" ? (
        <div className="space-y-6">
          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-base font-semibold">성과 요약</h2>
                <p className="mt-1 text-sm text-slate-600">조회수/좋아요/댓글/리포스트를 동기화해서 누적 성과를 확인합니다.</p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onSyncInsights(false)}
                  disabled={busy}
                  className="h-10 rounded-full border border-slate-200 px-4 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                >
                  성과 동기화
                </button>
                <button
                  type="button"
                  onClick={() => onSyncInsights(true)}
                  disabled={busy}
                  className="h-10 rounded-full bg-slate-900 px-4 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
                >
                  전체 강제 동기화
                </button>
              </div>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs text-slate-500">조회수</div>
                <div className="mt-1 text-2xl font-semibold">{performanceSummary.views.toLocaleString()}</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs text-slate-500">좋아요</div>
                <div className="mt-1 text-2xl font-semibold">{performanceSummary.likes.toLocaleString()}</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs text-slate-500">댓글</div>
                <div className="mt-1 text-2xl font-semibold">{performanceSummary.replies.toLocaleString()}</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs text-slate-500">리포스트</div>
                <div className="mt-1 text-2xl font-semibold">{performanceSummary.reposts.toLocaleString()}</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs text-slate-500">인용</div>
                <div className="mt-1 text-2xl font-semibold">{performanceSummary.quotes.toLocaleString()}</div>
              </div>
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <h3 className="text-base font-semibold">상위 성과 게시물</h3>
            <div className="mt-4 space-y-3">
              {topPosts.map((post) => (
                <div key={post.id} className="rounded-xl border border-slate-200 p-4">
                  <div className="line-clamp-2 text-sm text-slate-900">{post.text}</div>
                  <div className="mt-2 text-xs text-slate-600">
                    조회 {post.viewsCount} · 좋아요 {post.likesCount} · 댓글 {post.repliesCount} · 리포스트 {post.repostsCount} · 인용 {post.quotesCount}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500">업데이트: {post.insightsUpdatedAt ? new Date(post.insightsUpdatedAt).toLocaleString() : "-"}</div>
                  {post.insightsLastError ? <div className="mt-1 text-[11px] text-rose-600">동기화 오류: {post.insightsLastError}</div> : null}
                </div>
              ))}
              {topPosts.length === 0 ? <div className="text-sm text-slate-500">아직 원글 발행 데이터가 없습니다.</div> : null}
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex items-baseline justify-between gap-4">
              <h2 className="text-base font-semibold">게시 기록</h2>
              <div className="text-sm text-slate-500">{posts.length} items</div>
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="min-w-full border-separate border-spacing-0">
                <thead>
                  <tr className="text-left text-xs text-slate-500">
                    <th className="border-b border-slate-200 px-3 py-2">시간</th>
                    <th className="border-b border-slate-200 px-3 py-2">상태</th>
                    <th className="border-b border-slate-200 px-3 py-2">본문</th>
                    <th className="border-b border-slate-200 px-3 py-2">성과</th>
                    <th className="border-b border-slate-200 px-3 py-2">액션</th>
                  </tr>
                </thead>
                <tbody>
                  {posts.map((p) => (
                    <tr key={p.id} className="text-sm">
                      <td className="whitespace-nowrap border-b border-slate-100 px-3 py-3 text-slate-700">
                        {new Date(p.scheduledAt).toLocaleString()}
                      </td>
                      <td className="border-b border-slate-100 px-3 py-3">
                        <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${badgeClasses(p.status)}`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="border-b border-slate-100 px-3 py-3">
                        <div className="max-w-md whitespace-pre-wrap">{p.text}</div>
                      </td>
                      <td className="border-b border-slate-100 px-3 py-3 text-xs text-slate-600">
                        <div>조회 {p.viewsCount}</div>
                        <div>좋아요 {p.likesCount} · 댓글 {p.repliesCount}</div>
                        <div>리포스트 {p.repostsCount} · 인용 {p.quotesCount}</div>
                      </td>
                      <td className="border-b border-slate-100 px-3 py-3">
                        <div className="flex flex-wrap gap-2">
                          {(p.status === "FAILED" || p.status === "PARTIAL_FAILED") && (
                            <button
                              type="button"
                              className="h-9 rounded-full border border-slate-200 px-4 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                              disabled={busy}
                              onClick={() => onRetry(p.id)}
                            >
                              재시도
                            </button>
                          )}
                          {p.status !== "RUNNING" && p.status !== "SUCCESS" && !p.remotePostId ? (
                            <button
                              type="button"
                              className="h-9 rounded-full border border-rose-200 px-4 text-xs font-medium text-rose-700 hover:bg-rose-50 disabled:opacity-50"
                              disabled={busy}
                              onClick={() => onDeleteScheduledPost(p)}
                            >
                              삭제
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {posts.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-3 py-10 text-center text-sm text-slate-500">
                        아직 예약이 없습니다.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      ) : null}

      {tab === "settings" ? (
        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-base font-semibold">계정 설정</h2>
          <p className="mt-1 text-sm text-slate-600">라벨/프록시 URL을 관리하고, 필요 시 계정을 삭제할 수 있습니다.</p>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <label className="text-sm font-medium">라벨</label>
              <input
                className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                value={accountLabel}
                onChange={(e) => setAccountLabel(e.target.value)}
                disabled={busy}
                placeholder="예: 김프로_운영계정"
              />
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Proxy URL (옵션)</label>
              <input
                className="h-10 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-400"
                value={proxyUrl}
                onChange={(e) => setProxyUrl(e.target.value)}
                disabled={busy}
                placeholder="http://user:pass@host:port"
              />
            </div>
          </div>

          <div className="mt-4 text-xs text-slate-500">프록시 URL을 비우고 저장하면 계정 프록시가 제거됩니다.</div>

          <div className="mt-5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onSaveAccountSettings}
              disabled={busy}
              className="inline-flex h-10 items-center justify-center rounded-full bg-slate-900 px-5 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
            >
              계정 설정 저장
            </button>
            <button
              type="button"
              onClick={onDeleteAccount}
              disabled={busy}
              className="inline-flex h-10 items-center justify-center rounded-full border border-rose-200 bg-white px-5 text-sm font-medium text-rose-700 hover:bg-rose-50 disabled:opacity-50"
            >
              계정 삭제
            </button>
          </div>
        </section>
      ) : null}

      {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}
    </div>
  );
}
