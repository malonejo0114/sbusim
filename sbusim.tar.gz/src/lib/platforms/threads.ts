import { prisma } from "@/lib/prisma";
import { userIdFromLoginId } from "@/server/session";
import { ensureValidAccessToken } from "@/server/threadsToken";
import { createContainer, publishContainer } from "@/server/threadsApi";

function mediaTypeFromUrl(mediaUrl?: string) {
  if (!mediaUrl) return "TEXT" as const;
  const lower = mediaUrl.toLowerCase();
  if (lower.endsWith(".mp4") || lower.endsWith(".mov") || lower.includes("video")) return "VIDEO" as const;
  return "IMAGE" as const;
}

export async function getDefaultThreadsAccount() {
  const loginId = process.env.DASHBOARD_LOGIN_ID ?? "admin";
  const userId = userIdFromLoginId(loginId);

  const account = await prisma.threadsAccount.findFirst({
    where: { userId },
    orderBy: [{ updatedAt: "desc" }],
  });

  return account;
}

export async function isThreadsPostingAvailable() {
  const account = await getDefaultThreadsAccount();
  return Boolean(account);
}

export async function publishToThreads(args: {
  text: string;
  mediaUrl?: string | null;
  replyToId?: string;
}) {
  const account = await getDefaultThreadsAccount();
  if (!account) {
    return {
      posted: false as const,
      skipped: true as const,
      reason: "No connected Threads account for admin user",
    };
  }

  const { accessToken, proxyUrl } = await ensureValidAccessToken(account);
  const mediaType = mediaTypeFromUrl(args.mediaUrl ?? undefined);

  const container = await createContainer({
    accessToken,
    mediaType,
    text: args.text,
    imageUrl: mediaType === "IMAGE" ? args.mediaUrl ?? undefined : undefined,
    videoUrl: mediaType === "VIDEO" ? args.mediaUrl ?? undefined : undefined,
    replyToId: args.replyToId,
    proxyUrl,
  });

  const published = await publishContainer({
    accessToken,
    creationId: container.creationId,
    proxyUrl,
  });

  return {
    posted: true as const,
    skipped: false as const,
    postId: published.id,
  };
}
