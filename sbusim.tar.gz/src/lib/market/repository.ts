import { getSupabaseAdminClient } from "@/server/supabaseAdmin";
import type { MarketInstrumentRow, PostQueueStatus, PostQueueType, SourceLink } from "@/lib/market/types";

export type PostQueueRow = {
  id: string;
  platform: "threads";
  post_type: PostQueueType;
  dedupe_key: string | null;
  scheduled_at: string;
  status: PostQueueStatus;
  text: string;
  media_url: string | null;
  sources: SourceLink[];
  hide_sources: boolean;
  error: string | null;
  retries: number;
  posted_at: string | null;
  created_at: string;
};

export async function getEnabledMarketInstruments(): Promise<MarketInstrumentRow[]> {
  const supabase = getSupabaseAdminClient();
  const { data, error } = await supabase
    .from("market_instruments")
    .select("id,label,te_symbol,category,enabled,sort")
    .eq("enabled", true)
    .order("sort", { ascending: true });

  if (error) throw new Error(`market_instruments query failed: ${error.message}`);
  return (data ?? []) as MarketInstrumentRow[];
}

export async function upsertMarketSnapshots(
  asofDate: string,
  rows: Array<{ instrumentId: string; last: number; dailyPct: number; raw: Record<string, unknown> }>
) {
  const supabase = getSupabaseAdminClient();
  if (rows.length === 0) return;
  const payload = rows.map((row) => ({
    asof_date: asofDate,
    instrument_id: row.instrumentId,
    last: row.last,
    daily_pct: row.dailyPct,
    raw: row.raw,
  }));

  const { error } = await supabase
    .from("market_snapshots")
    .upsert(payload, { onConflict: "asof_date,instrument_id", ignoreDuplicates: false });

  if (error) throw new Error(`market_snapshots upsert failed: ${error.message}`);
}

export async function insertMarketChart(args: {
  asofDate: string;
  chartKind: "daily_snapshot_4pack" | "single_instrument_7d";
  imageUrl: string;
  meta: Record<string, unknown>;
}) {
  const supabase = getSupabaseAdminClient();
  const { error } = await supabase.from("market_charts").insert({
    asof_date: args.asofDate,
    chart_kind: args.chartKind,
    image_url: args.imageUrl,
    meta: args.meta,
  });
  if (error) throw new Error(`market_charts insert failed: ${error.message}`);
}

export async function upsertEconomicEvents(
  rows: Array<{
    eventDate: string;
    eventTimeIso: string | null;
    country: string;
    event: string;
    importance: number;
    sourceUrl: string;
    raw: Record<string, unknown>;
  }>
) {
  if (rows.length === 0) return;
  const supabase = getSupabaseAdminClient();
  const payload = rows.map((row) => ({
    event_date: row.eventDate,
    event_time: row.eventTimeIso,
    country: row.country,
    event: row.event,
    importance: row.importance,
    source_url: row.sourceUrl,
    raw: row.raw,
  }));

  const { error } = await supabase.from("economic_events").insert(payload);
  if (error) throw new Error(`economic_events insert failed: ${error.message}`);
}

export async function upsertCotSnapshots(
  rows: Array<{
    reportDate: string;
    marketCode: string;
    netNonCommercial: number;
    netChangeWoW: number;
    raw: Record<string, unknown>;
  }>
) {
  if (rows.length === 0) return;
  const supabase = getSupabaseAdminClient();
  const payload = rows.map((row) => ({
    report_date: row.reportDate,
    market_code: row.marketCode,
    net_noncommercial: row.netNonCommercial,
    net_change_wow: row.netChangeWoW,
    raw: row.raw,
  }));

  const { error } = await supabase
    .from("cot_snapshots")
    .upsert(payload, { onConflict: "report_date,market_code", ignoreDuplicates: false });

  if (error) throw new Error(`cot_snapshots upsert failed: ${error.message}`);
}

export async function listEnabledRssSources() {
  const supabase = getSupabaseAdminClient();
  const { data, error } = await supabase
    .from("content_sources")
    .select("id,name,url,enabled")
    .eq("enabled", true)
    .eq("type", "rss")
    .order("name", { ascending: true });

  if (error) throw new Error(`content_sources rss query failed: ${error.message}`);
  return (data ?? []) as Array<{ id: string; name: string; url: string; enabled: boolean }>;
}

export async function createOrGetPostQueue(args: {
  postType: PostQueueType;
  dedupeKey: string;
  scheduledAtIso: string;
  text: string;
  mediaUrl?: string | null;
  sources: SourceLink[];
  hideSources: boolean;
}) {
  const supabase = getSupabaseAdminClient();

  const { data: existing, error: existingErr } = await supabase
    .from("post_queue")
    .select("*")
    .eq("dedupe_key", args.dedupeKey)
    .maybeSingle();
  if (existingErr) throw new Error(`post_queue existing query failed: ${existingErr.message}`);
  if (existing) {
    return { row: existing as PostQueueRow, created: false };
  }

  const { data, error } = await supabase
    .from("post_queue")
    .insert({
      platform: "threads",
      post_type: args.postType,
      dedupe_key: args.dedupeKey,
      scheduled_at: args.scheduledAtIso,
      status: "queued",
      text: args.text,
      media_url: args.mediaUrl ?? null,
      sources: args.sources,
      hide_sources: args.hideSources,
    })
    .select("*")
    .single();

  if (error) throw new Error(`post_queue insert failed: ${error.message}`);
  return { row: data as PostQueueRow, created: true };
}

export async function updatePostQueue(args: {
  id: string;
  status?: PostQueueStatus;
  error?: string | null;
  retriesDelta?: number;
  postedAt?: string | null;
}) {
  const supabase = getSupabaseAdminClient();

  const patch: Record<string, unknown> = {};
  if (args.status) patch.status = args.status;
  if (args.error !== undefined) patch.error = args.error;
  if (args.postedAt !== undefined) patch.posted_at = args.postedAt;

  if (args.retriesDelta && args.retriesDelta !== 0) {
    const { data: existing, error } = await supabase
      .from("post_queue")
      .select("retries")
      .eq("id", args.id)
      .single();
    if (error) throw new Error(`post_queue retries query failed: ${error.message}`);
    patch.retries = Number(existing?.retries ?? 0) + args.retriesDelta;
  }

  const { error } = await supabase.from("post_queue").update(patch).eq("id", args.id);
  if (error) throw new Error(`post_queue update failed: ${error.message}`);
}

export async function insertPostLog(postId: string, step: string, message: string) {
  const supabase = getSupabaseAdminClient();
  const { error } = await supabase.from("post_logs").insert({ post_id: postId, step, message });
  if (error) throw new Error(`post_logs insert failed: ${error.message}`);
}

export async function listRecentPostQueue(limit = 50): Promise<PostQueueRow[]> {
  const supabase = getSupabaseAdminClient();
  const { data, error } = await supabase
    .from("post_queue")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(Math.max(1, Math.min(limit, 200)));

  if (error) throw new Error(`post_queue list failed: ${error.message}`);
  return (data ?? []) as PostQueueRow[];
}

export async function listRecentRssItems(limit = 30) {
  const supabase = getSupabaseAdminClient();
  const { data, error } = await supabase
    .from("rss_items")
    .select("source_id,guid,title,link,published_at,raw")
    .order("published_at", { ascending: false })
    .limit(Math.max(1, Math.min(limit, 200)));

  if (error) throw new Error(`rss_items list failed: ${error.message}`);
  return (data ?? []) as Array<{
    source_id: string;
    guid: string;
    title: string;
    link: string;
    published_at: string | null;
    raw: Record<string, unknown>;
  }>;
}
