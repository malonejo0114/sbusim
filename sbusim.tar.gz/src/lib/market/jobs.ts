import { nowKst, toKstDateKey } from "@/lib/market/time";
import {
  createOrGetPostQueue,
  getEnabledMarketInstruments,
  insertMarketChart,
  insertPostLog,
  listEnabledRssSources,
  listRecentPostQueue,
  listRecentRssItems,
  type PostQueueRow,
  updatePostQueue,
  upsertCotSnapshots,
  upsertEconomicEvents,
  upsertMarketSnapshots,
} from "@/lib/market/repository";
import { fetchSnapshot, fetchHistorical, tradingEconomicsSourceUrl } from "@/lib/market/tradingEconomics";
import { fetchTodayTopEvents } from "@/lib/market/calendar";
import { fetchLatestCotSnapshots, cftcSourceUrl } from "@/lib/market/cftc";
import { syncRssSource } from "@/lib/market/rss";
import { fetchFreeSnapshot, yahooSourceUrl } from "@/lib/market/freeMarket";
import { buildDailyCalendarCopy, buildDailySnapshotCopy, buildRssInsightCopy, buildWeeklyCotCopy } from "@/lib/market/copy";
import { renderDailySnapshot4Pack, uploadChartImage } from "@/lib/market/chartRenderer";
import { getSupabaseAdminClient } from "@/server/supabaseAdmin";
import { isThreadsPostingAvailable, publishToThreads } from "@/lib/platforms/threads";
import { optionalEnv } from "@/server/env";
import type { SourceLink } from "@/lib/market/types";

function errToString(err: unknown) {
  if (err instanceof Error) return `${err.name}: ${err.message}`;
  return String(err);
}

function resolveIncludeSources(flag?: boolean) {
  if (typeof flag === "boolean") return flag;
  return process.env.DEFAULT_INCLUDE_SOURCES !== "0";
}

function isTradingEconomicsEnabled() {
  return Boolean(optionalEnv("TE_API_KEY"));
}

function buildMockSnapshotPanels() {
  return [
    { label: "S&P 500", current: 5342.2, dailyPct: 0.62, series: [5250, 5271, 5290, 5311, 5302, 5330, 5342.2] },
    { label: "DXY", current: 104.18, dailyPct: -0.28, series: [104.9, 104.8, 104.6, 104.4, 104.5, 104.3, 104.18] },
    { label: "WTI", current: 77.45, dailyPct: 1.32, series: [74.2, 74.9, 75.8, 76.4, 76.1, 76.9, 77.45] },
    { label: "Gold", current: 2412.8, dailyPct: 0.41, series: [2361, 2375, 2388, 2397, 2401, 2408, 2412.8] },
  ];
}

async function tryPostQueueItem(row: PostQueueRow) {
  const canPost = await isThreadsPostingAvailable();
  if (!canPost) {
    await insertPostLog(row.id, "posting", "Threads 계정이 없어 posting 스킵(queued 유지)");
    return { posted: false as const, skipped: true as const };
  }

  await updatePostQueue({ id: row.id, status: "posting", error: null });
  await insertPostLog(row.id, "posting", "Threads 발행 시작");

  try {
    const result = await publishToThreads({ text: row.text, mediaUrl: row.media_url });

    if (!result.posted) {
      await updatePostQueue({ id: row.id, status: "queued", error: result.reason ?? "Posting skipped" });
      await insertPostLog(row.id, "posting_skipped", result.reason ?? "Posting skipped");
      return { posted: false as const, skipped: true as const };
    }

    await updatePostQueue({ id: row.id, status: "posted", postedAt: new Date().toISOString(), error: null });
    await insertPostLog(row.id, "posted", `Threads 게시 완료: ${result.postId}`);
    return { posted: true as const, skipped: false as const, postId: result.postId };
  } catch (err) {
    const msg = errToString(err);
    const nextRetries = row.retries + 1;
    const nextStatus = nextRetries >= 3 ? "failed" : "queued";
    await updatePostQueue({ id: row.id, status: nextStatus, error: msg, retriesDelta: 1 });
    await insertPostLog(row.id, "posting_failed", `retries=${nextRetries} ${msg}`);
    return { posted: false as const, skipped: false as const, error: msg };
  }
}

async function finalizeQueue(args: {
  dedupeKey: string;
  postType: "daily_snapshot" | "daily_calendar" | "weekly_cot" | "rss_insight";
  text: string;
  mediaUrl?: string;
  sources: SourceLink[];
  includeSources: boolean;
  scheduledAt?: string;
}) {
  const created = await createOrGetPostQueue({
    postType: args.postType,
    dedupeKey: args.dedupeKey,
    scheduledAtIso: args.scheduledAt ?? new Date().toISOString(),
    text: args.text,
    mediaUrl: args.mediaUrl,
    sources: args.sources,
    hideSources: !args.includeSources,
  });

  if (created.created) {
    await insertPostLog(created.row.id, "queued", `생성 완료 (${args.postType})`);
  } else {
    await insertPostLog(created.row.id, "dedupe", `중복 감지: ${args.dedupeKey}`);
  }

  if (created.row.status === "queued") {
    await tryPostQueueItem(created.row);
  }

  return created;
}

export async function renderDailySnapshotPreview(options?: { mockIfTeDisabled?: boolean }) {
  const asofDate = toKstDateKey(nowKst());
  const teEnabled = isTradingEconomicsEnabled();
  const panels = [] as Array<{ label: string; current: number; dailyPct: number; series: number[] }>;

  if (!teEnabled) {
    const instruments = await getEnabledMarketInstruments();
    const selected = instruments.slice(0, 4);
    if (selected.length >= 4) {
      const free = await fetchFreeSnapshot(selected, 7);
      for (const item of free) {
        panels.push({
          label: item.label,
          current: item.last,
          dailyPct: item.dailyPct,
          series: item.series,
        });
      }
    } else if (options?.mockIfTeDisabled) {
      panels.push(...buildMockSnapshotPanels());
    } else {
      throw new Error("market_instruments 활성 항목이 4개 이상 필요합니다.");
    }
  } else {
    const instruments = await getEnabledMarketInstruments();
    const selected = instruments.slice(0, 4);
    if (selected.length < 4) {
      throw new Error("market_instruments 활성 항목이 4개 이상 필요합니다.");
    }

    const snapshot = await fetchSnapshot(selected);
    for (const item of snapshot.slice(0, 4)) {
      const historical = await fetchHistorical(item.symbol, 7).catch(() => []);
      panels.push({
        label: item.label,
        current: item.last,
        dailyPct: item.dailyPct,
        series: historical.map((p) => p.close).filter((n) => Number.isFinite(n)),
      });
    }

    while (panels.length < 4) {
      panels.push({ label: `Panel ${panels.length + 1}`, current: 0, dailyPct: 0, series: [0, 0, 0, 0, 0, 0, 0] });
    }
  }

  const buffer = renderDailySnapshot4Pack(
    panels.map((p) => ({
      ...p,
      series: p.series.length >= 2 ? p.series : [p.current, p.current],
    })),
    asofDate
  );

  const supabase = getSupabaseAdminClient();
  const uploaded = await uploadChartImage({
    supabase,
    asofDate,
    chartKind: "daily_snapshot_4pack",
    buffer,
  });

  return {
    asofDate,
    chartUrl: uploaded.url,
    chartPath: uploaded.path,
    panels,
  };
}

export async function runDailySnapshotJob(options?: { includeSources?: boolean }) {
  const includeSources = resolveIncludeSources(options?.includeSources);
  const preview = await renderDailySnapshotPreview();
  const teEnabled = isTradingEconomicsEnabled();

  const instruments = await getEnabledMarketInstruments();
  const snapshot = teEnabled ? await fetchSnapshot(instruments) : await fetchFreeSnapshot(instruments, 7);
  await upsertMarketSnapshots(
    preview.asofDate,
    snapshot.map((s) => ({
      instrumentId: s.instrumentId,
      last: s.last,
      dailyPct: s.dailyPct,
      raw: s.raw,
    }))
  );

  await insertMarketChart({
    asofDate: preview.asofDate,
    chartKind: "daily_snapshot_4pack",
    imageUrl: preview.chartUrl,
    meta: {
      panels: preview.panels,
      chartPath: preview.chartPath,
    },
  });

  const sources: SourceLink[] = teEnabled
    ? [
        { name: "Trading Economics Markets Snapshot", url: tradingEconomicsSourceUrl("snapshot") },
        { name: "Trading Economics Markets Historical", url: tradingEconomicsSourceUrl("historical") },
      ]
    : Array.from(new Set(snapshot.map((s) => s.symbol).filter(Boolean)))
        .slice(0, 4)
        .map((symbol) => ({ name: `Yahoo Finance ${symbol}`, url: yahooSourceUrl(symbol) }));

  const text = await buildDailySnapshotCopy({
    asofDate: preview.asofDate,
    items: preview.panels.map((p) => ({ label: p.label, last: p.current, dailyPct: p.dailyPct })),
    sources,
    includeSources,
  });

  const dedupeKey = `daily_snapshot:${preview.asofDate}`;
  return finalizeQueue({
    dedupeKey,
    postType: "daily_snapshot",
    text,
    mediaUrl: preview.chartUrl,
    sources,
    includeSources,
  });
}

export async function runDailyCalendarJob(options?: { includeSources?: boolean }) {
  if (!isTradingEconomicsEnabled()) {
    return {
      skipped: true,
      reason: "Trading Economics 미사용 설정(TE_API_KEY 없음)으로 daily-calendar를 건너뜁니다.",
    };
  }

  const includeSources = resolveIncludeSources(options?.includeSources);
  const today = nowKst();
  const asofDate = toKstDateKey(today);

  const events = await fetchTodayTopEvents(today, 3, 5);
  await upsertEconomicEvents(events);

  const formatted = events.map((event) => ({
    timeKst: event.eventTimeIso
      ? new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Seoul", hour12: false }).format(
          new Date(event.eventTimeIso)
        )
      : "시간미정",
    country: event.country,
    event: event.event,
    importance: event.importance,
  }));

  const sources: SourceLink[] = [{ name: "Trading Economics Calendar", url: tradingEconomicsSourceUrl("calendar") }];
  const text = await buildDailyCalendarCopy({
    asofDate,
    topEvents: formatted,
    sources,
    includeSources,
  });

  const dedupeKey = `daily_calendar:${asofDate}`;
  return finalizeQueue({
    dedupeKey,
    postType: "daily_calendar",
    text,
    sources,
    includeSources,
  });
}

export async function runWeeklyCotJob(options?: { includeSources?: boolean }) {
  const includeSources = resolveIncludeSources(options?.includeSources);
  const snapshots = await fetchLatestCotSnapshots();
  if (snapshots.length === 0) throw new Error("COT 데이터가 비어 있습니다.");

  await upsertCotSnapshots(snapshots);

  const latestDate = snapshots
    .map((s) => s.reportDate)
    .sort((a, b) => (a < b ? 1 : -1))[0];

  const topMoves = snapshots
    .filter((s) => s.reportDate === latestDate)
    .sort((a, b) => Math.abs(b.netChangeWoW) - Math.abs(a.netChangeWoW))
    .slice(0, 3)
    .map((s) => ({
      marketCode: s.marketCode,
      net: s.netNonCommercial,
      wow: s.netChangeWoW,
    }));

  const sources: SourceLink[] = [{ name: "CFTC Public Reporting", url: cftcSourceUrl() }];
  const text = await buildWeeklyCotCopy({
    reportDate: latestDate,
    topMoves,
    sources,
    includeSources,
  });

  const dedupeKey = `weekly_cot:${latestDate}`;
  return finalizeQueue({
    dedupeKey,
    postType: "weekly_cot",
    text,
    sources,
    includeSources,
  });
}

function makeRssSummaryFromTitle(title: string) {
  const compact = title.replace(/\s+/g, " ").trim();
  if (!compact) return "핵심 뉴스 업데이트입니다.";
  return [
    `핵심 이슈: ${compact}`,
    "시장에 영향을 줄 수 있는 맥락을 체크하고 리스크를 관리하세요.",
    "세부 수치는 원문 링크에서 확인하는 것이 안전합니다.",
  ].join("\n");
}

export async function runRssInsightJob(options?: { includeSources?: boolean }) {
  const includeSources = resolveIncludeSources(options?.includeSources);
  const supabase = getSupabaseAdminClient();
  const sources = await listEnabledRssSources();

  if (sources.length === 0) throw new Error("활성화된 RSS 소스가 없습니다.");

  const syncWarnings: string[] = [];
  let syncedSourceCount = 0;
  for (const source of sources) {
    try {
      await syncRssSource(supabase, source, 30);
      syncedSourceCount += 1;
    } catch (err) {
      syncWarnings.push(`${source.name}: ${errToString(err)}`);
    }
  }

  if (syncedSourceCount === 0) {
    throw new Error(`모든 RSS 소스 동기화 실패: ${syncWarnings.join(" | ")}`);
  }

  const items = await listRecentRssItems(100);
  if (items.length === 0) throw new Error("RSS 아이템이 없습니다.");

  const candidate = items
    .filter((item) => item.title && item.link)
    .sort((a, b) => {
      if (!a.published_at || !b.published_at) return 0;
      return a.published_at < b.published_at ? 1 : -1;
    })[0];

  if (!candidate) throw new Error("게시 가능한 RSS 항목이 없습니다.");

  const source = sources.find((s) => s.id === candidate.source_id);
  const dedupeKey = `rss_insight:${candidate.source_id}:${candidate.guid}`;

  const sourceLinks: SourceLink[] = [
    { name: source?.name ?? "RSS Source", url: source?.url ?? candidate.link },
    { name: "원문", url: candidate.link },
  ];

  const text = await buildRssInsightCopy({
    topicTitle: candidate.title,
    summary: makeRssSummaryFromTitle(candidate.title),
    link: candidate.link,
    sourceName: source?.name ?? "RSS",
    sources: sourceLinks,
    includeSources,
  });

  const created = await finalizeQueue({
    dedupeKey,
    postType: "rss_insight",
    text,
    sources: sourceLinks,
    includeSources,
  });

  if (syncWarnings.length > 0) {
    await insertPostLog(created.row.id, "rss_source_warning", syncWarnings.join(" | ").slice(0, 1900));
  }

  return created;
}

export async function getRecentQueue(limit = 50) {
  return listRecentPostQueue(limit);
}

export async function postQueueById(postId: string) {
  const rows = await listRecentPostQueue(200);
  const row = rows.find((r) => r.id === postId);
  if (!row) throw new Error("post_queue item not found");
  return tryPostQueueItem(row);
}

export async function runAllForDebug(options?: { includeSources?: boolean }) {
  const includeSources = resolveIncludeSources(options?.includeSources);
  const result = {
    dailySnapshot: await runDailySnapshotJob({ includeSources }),
    dailyCalendar: await runDailyCalendarJob({ includeSources }),
    weeklyCot: await runWeeklyCotJob({ includeSources }),
    rssInsight: await runRssInsightJob({ includeSources }),
  };
  return result;
}
