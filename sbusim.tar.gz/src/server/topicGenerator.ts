import { fetchJsonWithRetry } from "@/server/fetchJson";
import { optionalEnv, requireEnv } from "@/server/env";

type PerplexityChatResponse = {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
};

type GeminiGenerateResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
};

type GeneratedPostItem = {
  text: string;
  firstComment?: string;
};

function parseJsonFromText<T>(raw: string): T | null {
  const trimmed = raw.trim();
  const fenced = trimmed.match(/```json\s*([\s\S]*?)```/i)?.[1]?.trim();
  const target = fenced ?? trimmed;

  try {
    return JSON.parse(target) as T;
  } catch {
    // Try best-effort extraction for wrapped prose.
    const firstBrace = target.indexOf("{");
    const lastBrace = target.lastIndexOf("}");
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      const sliced = target.slice(firstBrace, lastBrace + 1);
      try {
        return JSON.parse(sliced) as T;
      } catch {
        return null;
      }
    }
    return null;
  }
}

function collapseLineSpaces(line: string) {
  return line.replace(/\s+/g, " ").trim();
}

function splitSentences(text: string) {
  return text
    .split(/(?<=[.!?])\s+|(?<=다\.)\s+|(?<=요\.)\s+/g)
    .map((line) => collapseLineSpaces(line))
    .filter(Boolean);
}

function formatReadableText(v: string, maxLen = 500) {
  const normalized = v.replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
  if (!normalized) return "";

  const byLines = normalized
    .split("\n")
    .map((line) => collapseLineSpaces(line))
    .filter(Boolean);

  const readableLines = byLines.length >= 2 ? byLines : splitSentences(normalized);
  const lines = readableLines.length > 0 ? readableLines : [collapseLineSpaces(normalized)];

  // 가독성을 위해 줄 사이에 항상 한 줄 공백(엔터 2번)을 강제합니다.
  return lines.join("\n\n").slice(0, maxLen).trim();
}

function sanitizePostText(v: string) {
  return formatReadableText(v, 500);
}

type AiProvider = "perplexity" | "gemini";

function getAiProvider(): AiProvider {
  const explicit = optionalEnv("CONTENT_AI_PROVIDER")?.toLowerCase();
  if (explicit === "gemini") return "gemini";
  if (explicit === "perplexity") return "perplexity";
  if (optionalEnv("PERPLEXITY_API_KEY")) return "perplexity";
  if (optionalEnv("GEMINI_API_KEY")) return "gemini";
  throw new Error("Missing AI key: set PERPLEXITY_API_KEY or GEMINI_API_KEY");
}

async function callPerplexityJSON<T>(systemPrompt: string, userPrompt: string): Promise<T> {
  const apiKey = requireEnv("PERPLEXITY_API_KEY");
  const model = optionalEnv("PERPLEXITY_MODEL") ?? "sonar";
  const apiUrl = optionalEnv("PERPLEXITY_API_URL") ?? "https://api.perplexity.ai/chat/completions";

  const { json, text } = await fetchJsonWithRetry<PerplexityChatResponse>(
    apiUrl,
    {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
      }),
    },
    { timeoutMs: 30_000, retries: 2, backoffMs: 800 }
  );

  const content = json?.choices?.[0]?.message?.content?.trim();
  if (!content) {
    throw new Error(`Perplexity response missing content: ${text}`);
  }

  const parsed = parseJsonFromText<T>(content);
  if (!parsed) {
    throw new Error(`Perplexity response parse failed: ${content}`);
  }
  return parsed;
}

async function callGeminiJSON<T>(systemPrompt: string, userPrompt: string): Promise<T> {
  const apiKey = requireEnv("GEMINI_API_KEY");
  const model = optionalEnv("GEMINI_MODEL") ?? "gemini-2.0-flash";
  const defaultApiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const apiUrl = optionalEnv("GEMINI_API_URL") ?? defaultApiUrl;

  const url = new URL(apiUrl);
  if (!url.searchParams.has("key")) {
    url.searchParams.set("key", apiKey);
  }

  const { json, text } = await fetchJsonWithRetry<GeminiGenerateResponse>(
    url.toString(),
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        generationConfig: {
          temperature: 0.3,
          responseMimeType: "application/json",
        },
      }),
    },
    { timeoutMs: 30_000, retries: 2, backoffMs: 800 }
  );

  const content = (json?.candidates?.[0]?.content?.parts ?? [])
    .map((part) => part.text ?? "")
    .join("")
    .trim();
  if (!content) {
    throw new Error(`Gemini response missing content: ${text}`);
  }

  const parsed = parseJsonFromText<T>(content);
  if (!parsed) {
    throw new Error(`Gemini response parse failed: ${content}`);
  }
  return parsed;
}

async function callModelJSON<T>(systemPrompt: string, userPrompt: string): Promise<T> {
  const provider = getAiProvider();
  if (provider === "gemini") {
    return callGeminiJSON<T>(systemPrompt, userPrompt);
  }
  return callPerplexityJSON<T>(systemPrompt, userPrompt);
}

export async function generateDailyTopicPost(args: {
  topic: string;
  promptHint?: string;
  contentType?: "TOPIC" | "INFO" | "CTA";
  ctaText?: string;
  commentTemplate?: string;
}): Promise<{ text: string; commentText?: string }> {
  const contentType = args.contentType ?? "TOPIC";
  const styleGuide =
    contentType === "INFO"
      ? "정보성 글: 핵심 사실/배경/체크포인트를 명확히 정리하고, 홍보성 문구는 최소화."
      : contentType === "CTA"
        ? "CTA 글: 정보 2~3개를 먼저 제시한 뒤 마지막에 자연스러운 행동유도 문장을 넣으세요. 스팸/과장 금지."
        : "주제형 글: 오늘 관점의 핵심 포인트 2~3개를 균형 있게 정리.";

  const systemPrompt = [
    "당신은 한국어 Threads 콘텐츠 작성자입니다.",
    "반드시 JSON 하나만 출력하세요.",
    '형식: {"text":"...","firstComment":"..."}',
    "text는 500자 이내, 줄바꿈 허용, 사실 기반으로 작성.",
    "본문은 핵심 문장마다 줄바꿈하고, 문장 사이에 빈 줄 1개(\\n\\n)를 사용하세요.",
    "과도한 과장/투자 조언/확정적 표현은 금지.",
    "firstComment는 선택이며 없으면 빈 문자열.",
    styleGuide,
  ].join("\n");

  const userPrompt = [
    `콘텐츠 타입: ${contentType}`,
    `주제: ${args.topic}`,
    args.promptHint ? `추가 지시: ${args.promptHint}` : "",
    args.ctaText ? `CTA 문구 가이드(필요 시 활용): ${args.ctaText}` : "",
    args.commentTemplate ? `첫 댓글 톤 가이드: ${args.commentTemplate}` : "",
    "오늘 기준 핵심 2~3개를 반영해 본문을 작성해 주세요.",
  ]
    .filter(Boolean)
    .join("\n");

  const parsed = await callModelJSON<{ text?: string; firstComment?: string }>(systemPrompt, userPrompt);
  if (parsed?.text) {
    const main = sanitizePostText(parsed.text);
    if (!main) throw new Error("AI generated empty post text");
    const firstComment = parsed.firstComment?.trim() || undefined;
    return { text: main, commentText: firstComment };
  }

  const fallback = sanitizePostText(JSON.stringify(parsed));
  if (!fallback) throw new Error("AI generated empty response");
  return { text: fallback };
}

export async function generateIssueBriefingAndPosts(args: {
  issuePrompt: string;
  templatePrompt?: string;
  extraPrompt?: string;
  count: number;
}): Promise<{ briefing: string; posts: GeneratedPostItem[] }> {
  const targetCount = Math.max(1, Math.min(10, Math.floor(args.count)));

  const systemPrompt = [
    "당신은 한국어 Threads 콘텐츠 전략가입니다.",
    "반드시 JSON 하나만 출력하세요.",
    '형식: {"briefing":"...","posts":[{"text":"...","firstComment":"..."}]}',
    "briefing은 핵심 이슈 요약 4~7문장.",
    `posts는 정확히 ${targetCount}개 생성.`,
    "각 text는 500자 이내, 팩트 기반, 과장 금지.",
    "각 text의 문장 사이는 빈 줄 1개(\\n\\n)로 분리해 가독성을 높이세요.",
    "firstComment는 선택이며 없으면 빈 문자열.",
  ].join("\n");

  const userPrompt = [
    `이슈 질의: ${args.issuePrompt}`,
    args.templatePrompt ? `템플릿 지시: ${args.templatePrompt}` : "",
    args.extraPrompt ? `추가 지시: ${args.extraPrompt}` : "",
    "한국어로 작성해 주세요.",
  ]
    .filter(Boolean)
    .join("\n");

  const parsed = await callModelJSON<{
    briefing?: string;
    posts?: Array<{ text?: string; firstComment?: string }>;
  }>(systemPrompt, userPrompt);

  const briefing = formatReadableText(parsed.briefing ?? "", 1200);
  const rawPosts = Array.isArray(parsed.posts) ? parsed.posts : [];
  const posts = rawPosts
    .map((p) => ({
      text: sanitizePostText(p.text ?? ""),
      firstComment: (p.firstComment ?? "").trim() || undefined,
    }))
    .filter((p) => p.text.length > 0)
    .slice(0, targetCount);

  if (!briefing) {
    throw new Error("AI briefing is empty");
  }
  if (posts.length === 0) {
    throw new Error("AI generated no post candidates");
  }

  return { briefing, posts };
}
