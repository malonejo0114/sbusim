import { MediaType, ScheduledPostStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { createContainer, publishContainer } from "@/server/threadsApi";
import { ensureValidAccessToken } from "@/server/threadsToken";
import { enqueueCommentJob, enqueueInsightJob, enqueuePublishJob } from "@/server/queue";
import { syncPostInsightsBatch, syncScheduledPostInsightsById } from "@/server/insights";

function errorToString(err: unknown) {
  if (err instanceof Error) return `${err.name}: ${err.message}`;
  return String(err);
}

export async function handlePublishJob(scheduledPostId: string) {
  const claimed = await prisma.scheduledPost.updateMany({
    where: {
      id: scheduledPostId,
      // Include RUNNING so stalled jobs (worker crash) can be safely re-processed.
      status: {
        in: [
          ScheduledPostStatus.PENDING,
          ScheduledPostStatus.RUNNING,
          ScheduledPostStatus.FAILED,
          ScheduledPostStatus.PARTIAL_FAILED,
        ],
      },
    },
    data: { status: ScheduledPostStatus.RUNNING, lastError: null },
  });
  if (claimed.count === 0) return;

  const post = await prisma.scheduledPost.findUnique({
    where: { id: scheduledPostId },
    include: { threadsAccount: true },
  });
  if (!post) return;
  if (!post.threadsAccount) {
    await prisma.scheduledPost.update({
      where: { id: scheduledPostId },
      data: { status: ScheduledPostStatus.FAILED, lastError: "Missing Threads account" },
    });
    throw new Error("Missing Threads account");
  }

  let remotePostId = post.remotePostId ?? null;

  try {
    // Idempotency: if we've already published the main post, never publish again.
    const { accessToken, proxyUrl } = await ensureValidAccessToken(post.threadsAccount);

    if (!remotePostId) {
      const mediaType = post.mediaType as unknown as MediaType;

      const container = await createContainer({
        accessToken,
        mediaType,
        text: post.text,
        imageUrl: mediaType === MediaType.IMAGE ? post.mediaUrl ?? undefined : undefined,
        videoUrl: mediaType === MediaType.VIDEO ? post.mediaUrl ?? undefined : undefined,
        proxyUrl,
      });

      const published = await publishContainer({
        accessToken,
        creationId: container.creationId,
        proxyUrl,
      });
      remotePostId = published.id;

      await prisma.scheduledPost.update({
        where: { id: scheduledPostId },
        data: { remotePostId },
      });
    }

    if (post.commentText && !post.remoteCommentId) {
      await enqueueCommentJob({
        scheduledPostId,
        delayMs: Math.max(0, (post.commentDelaySeconds ?? 0) * 1000),
      });

      // Keep RUNNING until the comment is attempted/completed.
      await prisma.scheduledPost.update({
        where: { id: scheduledPostId },
        data: { status: ScheduledPostStatus.RUNNING, lastError: null },
      });
      return;
    }

    await prisma.scheduledPost.update({
      where: { id: scheduledPostId },
      data: { status: ScheduledPostStatus.SUCCESS, lastError: null },
    });
    await enqueueInsightJob({ scheduledPostId, delayMs: 30_000 }).catch((err) => {
      console.error("[insights] enqueue failed after publish:", { scheduledPostId, error: errorToString(err) });
    });
  } catch (err) {
    const msg = errorToString(err);
    const status = remotePostId ? ScheduledPostStatus.PARTIAL_FAILED : ScheduledPostStatus.FAILED;
    await prisma.scheduledPost.update({
      where: { id: scheduledPostId },
      data: { status, lastError: msg },
    });
    throw err;
  }
}

export async function handleCommentJob(scheduledPostId: string) {
  const claimed = await prisma.scheduledPost.updateMany({
    where: {
      id: scheduledPostId,
      status: { in: [ScheduledPostStatus.RUNNING, ScheduledPostStatus.PENDING, ScheduledPostStatus.PARTIAL_FAILED] },
      remotePostId: { not: null },
      remoteCommentId: null,
      commentText: { not: null },
    },
    data: { status: ScheduledPostStatus.RUNNING, lastError: null },
  });
  if (claimed.count === 0) return;

  const post = await prisma.scheduledPost.findUnique({
    where: { id: scheduledPostId },
    include: { threadsAccount: true },
  });
  if (!post || !post.threadsAccount || !post.remotePostId || !post.commentText) return;

  try {
    const { accessToken, proxyUrl } = await ensureValidAccessToken(post.threadsAccount);

    const container = await createContainer({
      accessToken,
      mediaType: MediaType.TEXT,
      text: post.commentText,
      replyToId: post.remotePostId,
      proxyUrl,
    });

    const published = await publishContainer({
      accessToken,
      creationId: container.creationId,
      proxyUrl,
    });

    await prisma.scheduledPost.update({
      where: { id: scheduledPostId },
      data: {
        remoteCommentId: published.id,
        status: ScheduledPostStatus.SUCCESS,
        lastError: null,
      },
    });
    await enqueueInsightJob({ scheduledPostId, delayMs: 30_000 }).catch((err) => {
      console.error("[insights] enqueue failed after comment:", { scheduledPostId, error: errorToString(err) });
    });
  } catch (err) {
    const msg = errorToString(err);
    await prisma.scheduledPost.update({
      where: { id: scheduledPostId },
      data: { status: ScheduledPostStatus.PARTIAL_FAILED, lastError: msg },
    });
    throw err;
  }
}

export async function handleInsightJob(scheduledPostId: string) {
  const result = await syncScheduledPostInsightsById(scheduledPostId);
  if (!result.ok && result.reason !== "not_found" && result.reason !== "missing_remote_or_account") {
    throw new Error(result.reason);
  }
}

export async function handleInsightsSyncJob() {
  const result = await syncPostInsightsBatch({ force: false, limit: 150 });
  console.log("[insights] sync batch:", result);
}
