import { cookies } from "next/headers";
import { session, sessionCookieOptions, userIdFromLoginId } from "@/server/session";
import { AUTH_COOKIE_NAME, getDashboardLoginConfig } from "@/server/auth";

export async function ensureSessionUserId(): Promise<{ userId: string; setCookie: boolean }> {
  const store = await cookies();
  const existing = store.get(session.cookieName)?.value;
  if (existing) {
    return { userId: existing, setCookie: false };
  }

  const hasAuth = Boolean(store.get(AUTH_COOKIE_NAME)?.value);
  if (hasAuth) {
    const { loginId } = getDashboardLoginConfig();
    const userId = userIdFromLoginId(loginId);
    return { userId, setCookie: true };
  }

  const userId = crypto.randomUUID();
  return { userId, setCookie: true };
}

export { sessionCookieOptions };
