import { cookies } from "next/headers";

export const AUTH_COOKIE_NAME = "sbusim_auth";

export function authCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 14, // 14 days
  };
}

export function getDashboardLoginConfig() {
  const loginId = process.env.DASHBOARD_LOGIN_ID ?? "admin";
  const loginPassword = process.env.DASHBOARD_LOGIN_PASSWORD;
  if (!loginPassword) {
    throw new Error("Missing required env var: DASHBOARD_LOGIN_PASSWORD");
  }
  return { loginId, loginPassword };
}

export async function isAuthenticated() {
  const store = await cookies();
  return Boolean(store.get(AUTH_COOKIE_NAME)?.value);
}
